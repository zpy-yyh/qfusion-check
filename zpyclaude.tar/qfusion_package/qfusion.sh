#!/bin/bash

# QFusion统一管理脚本
# 支持单节点和批量节点的检查与初始化
# 包含本地YUM源配置功能

# 创建expect脚本函数
create_expect_scripts() {
    # 创建SSH连接脚本
    cat > /root/ssh_connect.exp << 'EOF'
#!/usr/bin/expect -f

# SSH连接expect脚本
# 用法: ssh_connect.exp <host> <user> <password> <command>

set timeout 10
set host [lindex $argv 0]
set user [lindex $argv 1]
set password [lindex $argv 2]
set command [lindex $argv 3]

if {[llength $argv] < 4} {
    puts "Usage: $argv0 <host> <user> <password> <command>"
    exit 1
}

# 禁用输出
log_user 0

spawn ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 $user@$host $command

expect {
    "password:" {
        send "$password\r"
        log_user 1
        expect {
            eof {
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
            "Permission denied" {
                puts stderr "Authentication failed"
                exit 1
            }
        }
    }
    "Are you sure you want to continue connecting" {
        send "yes\r"
        expect "password:"
        send "$password\r"
        log_user 1
        expect eof
    }
    eof {
        puts stderr "Connection failed"
        exit 1
    }
    timeout {
        puts stderr "Connection timeout"
        exit 1
    }
}
EOF
    chmod +x /root/ssh_connect.exp
    
    # 创建SCP脚本
    cat > /root/scp_file.exp << 'EOF'
#!/usr/bin/expect -f

# SCP文件传输expect脚本
# 用法: scp_file.exp <source> <user> <host> <dest> <password>

set timeout 30
set source [lindex $argv 0]
set user [lindex $argv 1]
set host [lindex $argv 2]
set dest [lindex $argv 3]
set password [lindex $argv 4]

if {[llength $argv] < 5} {
    puts stderr "Usage: $argv0 <source> <user> <host> <dest> <password>"
    exit 1
}

# 禁用输出
log_user 0

# 构建完整的SCP目标
set scp_target "$user@$host:$dest"

spawn scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $source $scp_target

expect {
    -re "password:" {
        send "$password\r"
        expect {
            -re "100%" {
                expect eof
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
            -re "Permission denied" {
                puts stderr "Authentication failed"
                exit 1
            }
            -re "No such file or directory" {
                puts stderr "File or directory not found"
                exit 1
            }
            eof {
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
            timeout {
                puts stderr "Transfer timeout"
                exit 1
            }
        }
    }
    -re "Are you sure you want to continue connecting.*" {
        send "yes\r"
        expect -re "password:"
        send "$password\r"
        expect {
            -re "100%" {
                expect eof
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
            eof {
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
            timeout {
                puts stderr "Transfer timeout"
                exit 1
            }
        }
    }
    -re "No route to host" {
        puts stderr "Cannot reach host"
        exit 1
    }
    -re "Connection refused" {
        puts stderr "Connection refused"
        exit 1
    }
    timeout {
        puts stderr "Connection timeout"
        exit 1
    }
    eof {
        catch wait result
        set exit_status [lindex $result 3]
        if {$exit_status != 0} {
            puts stderr "Transfer failed"
        }
        exit $exit_status
    }
}
EOF
    chmod +x /root/scp_file.exp
    
    # 创建长时间运行的SSH脚本
    cat > /root/ssh_long_run.exp << 'EOF'
#!/usr/bin/expect -f

# SSH长时间运行命令expect脚本
set timeout -1
set host [lindex $argv 0]
set user [lindex $argv 1]
set password [lindex $argv 2]
set command [lindex $argv 3]

if {[llength $argv] < 4} {
    puts stderr "Usage: $argv0 <host> <user> <password> <command>"
    exit 1
}

log_user 1

spawn ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -o UserKnownHostsFile=/dev/null -o PasswordAuthentication=yes -o PubkeyAuthentication=no -o ServerAliveInterval=60 -o ServerAliveCountMax=3 $user@$host $command

expect {
    -re ".*assword:" {
        send "$password\r"
        expect {
            -re "Permission denied.*" {
                puts stderr "\nAuthentication failed: wrong password"
                exit 1
            }
            eof {
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
        }
    }
    -re "Are you sure you want to continue connecting.*" {
        send "yes\r"
        expect -re ".*assword:"
        send "$password\r"
        expect {
            -re "Permission denied.*" {
                puts stderr "\nAuthentication failed"
                exit 1
            }
            eof {
                catch wait result
                set exit_status [lindex $result 3]
                exit $exit_status
            }
        }
    }
    timeout {
        puts stderr "Connection timeout to $host"
        exit 1
    }
    eof {
        puts stderr "Connection failed to $host"
        exit 1
    }
}
EOF
    chmod +x /root/ssh_long_run.exp
    
    # 创建远程初始化expect脚本
    cat > /root/ssh_remote_init.exp << 'EOF'
#!/usr/bin/expect -f

# SSH远程初始化expect脚本
set timeout -1
set host [lindex $argv 0]
set user [lindex $argv 1]
set password [lindex $argv 2]

if {[llength $argv] < 3} {
    puts "Usage: $argv0 <host> <user> <password>"
    exit 1
}

log_user 1

spawn ssh -t -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o PasswordAuthentication=yes -o PubkeyAuthentication=no $user@$host

expect {
    "password:" {
        send "$password\r"
        expect {
            "Permission denied" {
                puts stderr "\nAuthentication failed"
                exit 1
            }
            -re ".*#.*|.*\\$.*" {
                # 登录成功，执行初始化脚本
                send "bash /tmp/qfusion_remote.sh --remote-init\r"
                
                # 进入交互模式，让用户可以完成RAID配置等操作
                interact {
                    eof {
                        puts "\n[远程初始化完成]"
                        exit 0
                    }
                }
            }
            timeout {
                puts stderr "\nLogin timeout"
                exit 1
            }
        }
    }
    "Are you sure you want to continue connecting" {
        send "yes\r"
        expect "password:"
        send "$password\r"
        expect {
            "Permission denied" {
                puts stderr "\nAuthentication failed"
                exit 1
            }
            -re ".*#.*|.*\\$.*" {
                send "bash /tmp/qfusion_remote.sh --remote-init\r"
                interact {
                    eof {
                        puts "\n[远程初始化完成]"
                        exit 0
                    }
                }
            }
        }
    }
    timeout {
        puts stderr "\nConnection timeout"
        exit 1
    }
    eof {
        puts stderr "\nConnection failed"
        exit 1
    }
}
EOF
    chmod +x /root/ssh_remote_init.exp
    
    # 创建智能初始化expect脚本（无中文字符）
    cat > /root/ssh_smart_init.exp << 'EOF'
#!/usr/bin/expect -f

# Smart SSH initialization script
set timeout 300
set host [lindex $argv 0]
set user [lindex $argv 1]
set password [lindex $argv 2]
set skip_raid [lindex $argv 3]

if {[llength $argv] < 3} {
    puts "Usage: $argv0 <host> <user> <password> [skip_raid:yes/no]"
    exit 1
}

if {[llength $argv] < 4} {
    set skip_raid "yes"
}

log_user 1

spawn ssh -t -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o ServerAliveInterval=30 -o ServerAliveCountMax=3 \
    -o ConnectTimeout=10 $user@$host

expect {
    "password:" {
        send "$password\r"
        expect {
            "Permission denied" {
                puts stderr "\nAuthentication failed"
                exit 1
            }
            -re ".*#.*|.*\\$.*" {
                puts "\n\[Connected to $host\]"
            }
        }
    }
    "Are you sure you want to continue connecting" {
        send "yes\r"
        expect "password:"
        send "$password\r"
        expect -re ".*#.*|.*\\$.*" {
            puts "\n\[Connected to $host\]"
        }
    }
}

# Execute initialization script
send "bash /tmp/qfusion_remote.sh --remote-init 2>&1\r"

# Smart response loop
set init_complete 0
set response_count 0

while {$init_complete == 0 && $response_count < 50} {
    expect {
        -re ".*1.*2.*|.*RAID.*" {
            incr response_count
            if {$skip_raid == "yes"} {
                send "2\r"
            } else {
                send "1\r"
            }
            exp_continue
        }
        -re ".*disk.*|.*q.*quit.*" {
            incr response_count
            if {$skip_raid == "yes"} {
                send "q\r"
            } else {
                send "0,1\r"
            }
            exp_continue
        }
        -re ".*\\(y/n\\).*" {
            incr response_count
            send "y\r"
            exp_continue
        }
        -re ".*0.*exit.*" {
            incr response_count
            send "0\r"
            exp_continue
        }
        -re ".*#\[\\s\]*$" {
            set init_complete 1
            send "exit\r"
            expect eof
            exit 0
        }
        eof {
            exit 0
        }
        timeout {
            incr response_count
            if {$response_count >= 50} {
                send "\003"
                send "exit\r"
                expect eof
                exit 1
            } else {
                send "\r"
                exp_continue
            }
        }
    }
}

send "exit\r"
expect eof
exit 0
EOF
    chmod +x /root/ssh_smart_init.exp
}

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# 全局变量
NODES_FILE="nodes.conf"
RESULTS_DIR=""
CHECK_SCRIPT="/tmp/qfusion_check_only.sh"

# 检查结果存储（单节点使用）
declare -A CHECK_RESULTS
declare -A CHECK_STATUS
declare -A CHECK_DETAILS

echo_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo_blue() {
    echo -e "${BLUE}[*]${NC} $1"
}

# 显示分隔线
show_separator() {
    echo "=========================================="
}

# 自动确认函数
auto_confirm() {
    local prompt="$1"
    local default="${2:-Y}"
    
    # 如果设置了自动确认模式，直接返回默认值
    if [ "$AUTO_CONFIRM" = "1" ]; then
        echo "$prompt [自动确认: $default]"
        if [[ "$default" =~ ^[Yy]$ ]]; then
            return 0
        else
            return 1
        fi
    fi
    
    # 否则正常交互
    read -p "$prompt" answer
    answer=${answer:-$default}
    if [[ "$answer" =~ ^[Yy]$ ]]; then
        return 0
    else
        return 1
    fi
}

# ================== YUM源配置相关函数 ==================

# 恢复在线YUM源
restore_online_yum_repos() {
    echo_info "恢复在线YUM源配置..."
    
    # 检测系统版本
    local os_name=""
    local os_version=""
    
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        os_name="$ID"
        os_version="$VERSION_ID"
    fi
    
    # 备份当前配置
    local backup_dir="/etc/yum.repos.d/backup_$(date +%Y%m%d_%H%M%S)"
    if ls /etc/yum.repos.d/*.repo &>/dev/null 2>&1; then
        echo_info "备份当前配置到: $backup_dir"
        mkdir -p "$backup_dir"
        cp /etc/yum.repos.d/*.repo "$backup_dir/"
    fi
    
    # 根据系统类型恢复YUM源
    case "$os_name" in
        centos)
            echo_info "恢复CentOS官方源..."
            # CentOS 7
            if [[ "$os_version" == "7"* ]]; then
                cat > /etc/yum.repos.d/CentOS-Base.repo << 'EOF'
[base]
name=CentOS-$releasever - Base
baseurl=http://mirror.centos.org/centos/$releasever/os/$basearch/
        http://mirrors.aliyun.com/centos/$releasever/os/$basearch/
        http://mirrors.163.com/centos/$releasever/os/$basearch/
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7

[updates]
name=CentOS-$releasever - Updates
baseurl=http://mirror.centos.org/centos/$releasever/updates/$basearch/
        http://mirrors.aliyun.com/centos/$releasever/updates/$basearch/
        http://mirrors.163.com/centos/$releasever/updates/$basearch/
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7

[extras]
name=CentOS-$releasever - Extras
baseurl=http://mirror.centos.org/centos/$releasever/extras/$basearch/
        http://mirrors.aliyun.com/centos/$releasever/extras/$basearch/
        http://mirrors.163.com/centos/$releasever/extras/$basearch/
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
EOF
            fi
            ;;
            
        rhel|redhat)
            echo_warn "RedHat系统需要订阅才能使用官方源"
            echo_info "尝试配置兼容的CentOS源..."
            ;;
            
        kylin)
            echo_info "恢复麒麟系统源..."
            # 麒麟系统的YUM源配置
            ;;
            
        *)
            echo_warn "未识别的系统类型: $os_name"
            echo_info "请手动配置YUM源"
            return 1
            ;;
    esac
    
    # 测试恢复的源
    echo_info "测试恢复的YUM源..."
    yum clean all &>/dev/null
    if timeout 15 yum makecache &>/dev/null; then
        echo_info "在线YUM源恢复成功"
        yum repolist
        return 0
    else
        echo_error "在线YUM源恢复失败"
        echo_info "可能需要检查网络连接或手动配置"
        return 1
    fi
}

# 配置本地ISO YUM源
setup_local_yum_source() {
    echo ""
    show_separator
    echo "        配置本地ISO YUM源"
    show_separator
    echo ""
    
    # 自动搜索ISO文件
    echo_info "搜索系统中的ISO文件..."
    local iso_files=()
    local search_dirs=("/root" "/mnt" "/tmp" "/opt" "/home")
    
    for dir in "${search_dirs[@]}"; do
        if [ -d "$dir" ]; then
            while IFS= read -r -d '' file; do
                iso_files+=("$file")
            done < <(find "$dir" -maxdepth 3 -name "*.iso" -type f -print0 2>/dev/null)
        fi
    done
    
    local iso_path=""
    
    if [ ${#iso_files[@]} -gt 0 ]; then
        echo ""
        echo "找到以下ISO文件:"
        local i=1
        for iso in "${iso_files[@]}"; do
            local size=$(du -h "$iso" 2>/dev/null | cut -f1)
            echo "  $i. $iso ($size)"
            ((i++))
        done
        echo "  0. 手动输入路径"
        echo "  q. 退出"
        echo ""
        read -p "请选择ISO文件 [1-${#iso_files[@]}/0/q]: " choice
        
        if [[ "$choice" == "q" ]] || [[ "$choice" == "Q" ]]; then
            return 1
        elif [[ "$choice" == "0" ]]; then
            read -p "请输入ISO文件完整路径: " iso_path
        elif [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le ${#iso_files[@]} ]; then
            iso_path="${iso_files[$((choice-1))]}"
        else
            echo_error "无效选择"
            return 1
        fi
    else
        echo_warn "未找到ISO文件"
        read -p "请输入ISO文件完整路径 (输入q退出): " iso_path
    fi
    
    if [[ "$iso_path" == "q" ]] || [[ "$iso_path" == "Q" ]]; then
        return 1
    fi
    
    # 去除路径两端的空格
    iso_path=$(echo "$iso_path" | xargs)
    
    # 验证ISO文件
    if [ ! -f "$iso_path" ]; then
        echo_error "ISO文件不存在: $iso_path"
        read -p "按回车键继续..."
        return 1
    fi
    
    echo_info "使用ISO文件: $iso_path"
    
    # 备份现有YUM配置
    local backup_dir="/etc/yum.repos.d/backup_$(date +%Y%m%d_%H%M%S)"
    if ls /etc/yum.repos.d/*.repo &>/dev/null 2>&1; then
        echo_info "备份现有YUM配置到: $backup_dir"
        mkdir -p "$backup_dir"
        mv /etc/yum.repos.d/*.repo "$backup_dir/"
    fi
    
    # 挂载ISO
    local mount_point="/mnt/cdrom"
    mkdir -p "$mount_point"
    
    # 检查是否已挂载
    if mount | grep -q "$mount_point"; then
        echo_warn "卸载现有挂载..."
        umount "$mount_point" 2>/dev/null || true
    fi
    
    # 挂载ISO
    echo_info "挂载ISO文件..."
    mount -o loop,ro "$iso_path" "$mount_point"
    
    if [ $? -ne 0 ]; then
        echo_error "ISO挂载失败"
        return 1
    fi
    
    # 创建repo配置
    echo_info "创建YUM源配置..."
    cat > /etc/yum.repos.d/local-iso.repo << EOF
[local-iso]
name=Local ISO Repository
baseurl=file://$mount_point
enabled=1
gpgcheck=0
priority=1
EOF
    
    # 检测额外的repo路径（如BaseOS, AppStream）
    if [ -d "$mount_point/BaseOS" ]; then
        cat >> /etc/yum.repos.d/local-iso.repo << EOF

[local-iso-BaseOS]
name=Local ISO Repository - BaseOS
baseurl=file://$mount_point/BaseOS
enabled=1
gpgcheck=0
priority=1
EOF
    fi
    
    if [ -d "$mount_point/AppStream" ]; then
        cat >> /etc/yum.repos.d/local-iso.repo << EOF

[local-iso-AppStream]
name=Local ISO Repository - AppStream
baseurl=file://$mount_point/AppStream
enabled=1
gpgcheck=0
priority=1
EOF
    fi
    
    # 询问是否配置自动挂载
    echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
    read -p "是否配置开机自动挂载? [Y/n]: " answer
    fi
    if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
        # 先移除可能存在的旧条目
        sed -i "\|$iso_path|d" /etc/fstab
        sed -i "\|$mount_point|d" /etc/fstab
        # 添加新条目
        echo "$iso_path $mount_point iso9660 loop,ro 0 0" >> /etc/fstab
        echo_info "已配置开机自动挂载"
    fi
    
    # 清理并测试YUM源
    echo_info "清理YUM缓存..."
    yum clean all &>/dev/null
    
    echo_info "测试YUM源（可能需要几秒钟）..."
    if timeout 15 yum makecache &>/dev/null; then
        echo_info "YUM源配置成功！"
        
        # 显示可用包数量
        local pkg_count=$(yum list available 2>/dev/null | wc -l)
        echo_info "可用软件包数量: $pkg_count"
        
        # 测试安装sshpass
        echo ""
        if ! command -v sshpass &>/dev/null; then
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
            read -p "是否安装sshpass（批量管理需要）? [Y/n]: " answer
    fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                if yum install -y sshpass; then
                    echo_info "sshpass安装成功"
                else
                    echo_warn "sshpass安装失败，可能需要EPEL源"
                fi
            fi
        else
            echo_info "sshpass已安装"
        fi
        
        return 0
    else
        echo_error "YUM源配置失败"
        return 1
    fi
}

# ================== 单节点检查和修复函数 ==================

# 0. 检查并配置YUM源
check_and_fix_yum_source() {
    echo_blue "检查YUM源配置..."
    
    # 先检查网络连接性
    local network_ok=0
    if ping -c 1 -W 2 114.114.114.114 &>/dev/null || ping -c 1 -W 2 8.8.8.8 &>/dev/null; then
        network_ok=1
    fi
    
    # 检查现有YUM源
    local yum_status="unknown"
    local has_local_iso=0
    local has_online_repo=0
    local repo_count=0
    
    # 统计repo文件数量
    if [ -d /etc/yum.repos.d ]; then
        repo_count=$(ls /etc/yum.repos.d/*.repo 2>/dev/null | wc -l)
    fi
    
    # 检查本地ISO挂载
    if mount | grep -q "/mnt/cdrom"; then
        has_local_iso=1
    fi
    
    # 测试YUM缓存（带超时）
    if timeout 10 yum makecache &>/dev/null 2>&1; then
        yum_status="working"
        
        # 检查是否有在线仓库
        if [ $network_ok -eq 1 ] && yum repolist 2>/dev/null | grep -qE "(centos|rhel|kylin|base|updates)"; then
            has_online_repo=1
        fi
    else
        yum_status="failed"
    fi
    
    # 显示检查结果
    if [ "$yum_status" = "working" ]; then
        CHECK_STATUS["yum_source"]="PASS"
        echo -e "${GREEN}✓${NC} YUM源: 配置正常"
        
        if [ $has_local_iso -eq 1 ]; then
            echo "   ${GREEN}✓${NC} 本地ISO源: $(mount | grep /mnt/cdrom | awk '{print $1}')"
        fi
        
        if [ $has_online_repo -eq 1 ]; then
            echo "   ${GREEN}✓${NC} 在线仓库: 可用"
        elif [ $network_ok -eq 0 ]; then
            echo "   ${YELLOW}!${NC} 网络不可用，仅使用本地源"
        fi
        
        echo "   仓库配置文件: $repo_count 个"
        
        # 只在CHECK_ONLY模式下直接返回
        if [[ -n "$CHECK_ONLY" ]]; then
            return
        fi
    else
        CHECK_STATUS["yum_source"]="FAIL"
        echo -e "${RED}✗${NC} YUM源: 配置异常或不可用"
        
        # 分析失败原因
        if [ $repo_count -eq 0 ]; then
            echo "   ${RED}✗${NC} 未找到任何YUM仓库配置文件"
        fi
        
        if [ $network_ok -eq 0 ] && [ $has_local_iso -eq 0 ]; then
            echo "   ${YELLOW}!${NC} 网络不可用且无本地ISO源"
        fi
        
        # 只检查模式直接返回
        if [[ -n "$CHECK_ONLY" ]]; then
            return
        fi
        
        echo ""
        echo "   YUM源配置异常可能导致软件包无法安装"
        
        # 提供修复选项
        if [ "$AUTO_CONFIRM" = "1" ]; then
            answer="y"
            echo "配置本地ISO YUM源? [Y/n]: [自动确认: Y]"
        else
            echo "请选择修复方式:"
            echo "1. 配置本地ISO YUM源（推荐）"
            echo "2. 尝试恢复在线YUM源"
            echo "3. 跳过YUM源配置"
            read -p "请选择 [1/2/3]: " answer
        fi
        
        case "$answer" in
            1|y|Y|"")
                if setup_local_yum_source; then
                    CHECK_STATUS["yum_source"]="FIXED"
                fi
                ;;
            2)
                echo_info "尝试恢复在线YUM源..."
                restore_online_yum_repos
                ;;
            3|n|N)
                echo_warn "跳过YUM源配置"
                ;;
            *)
                echo_warn "无效选择，跳过YUM源配置"
                ;;
        esac
    fi
}

# 1. 检查并修复硬件时间
check_and_fix_hardware_time() {
    echo_blue "检查硬件时间同步状态..."
    
    local sys_time=$(date '+%s')
    local sys_time_str=$(date '+%Y-%m-%d %H:%M:%S')
    local hw_time_str=$(hwclock -r 2>/dev/null || echo "ERROR")
    
    if [ "$hw_time_str" = "ERROR" ]; then
        CHECK_STATUS["hardware_time"]="FAIL"
        echo -e "${RED}✗${NC} 硬件时间: 无法读取"
        return
    fi
    
    local hw_time=$(date -d "$hw_time_str" '+%s' 2>/dev/null || echo "0")
    
    if [ "$hw_time" = "0" ]; then
        CHECK_STATUS["hardware_time"]="FAIL"
        echo -e "${RED}✗${NC} 硬件时间: 格式错误"
        return
    fi
    
    local time_diff=$((sys_time - hw_time))
    [ $time_diff -lt 0 ] && time_diff=$((-time_diff))
    
    if [ $time_diff -le 2 ]; then
        CHECK_STATUS["hardware_time"]="PASS"
        echo -e "${GREEN}✓${NC} 硬件时间: 与系统时间同步"
        echo "   系统时间: $sys_time_str"
        echo "   硬件时间: $hw_time_str"
    else
        CHECK_STATUS["hardware_time"]="FAIL"
        echo -e "${RED}✗${NC} 硬件时间: 与系统时间不同步 (差异:${time_diff}秒)"
        echo "   系统时间: $sys_time_str"
        echo "   硬件时间: $hw_time_str"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
            read -p "是否将系统时间写入硬件时间? [Y/n]: " answer
    fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                hwclock -w
                echo_info "已将系统时间写入硬件时间"
                CHECK_STATUS["hardware_time"]="FIXED"
            fi
        fi
    fi
}

# 2. 检查并修复网卡速率
check_and_fix_network_speed() {
    echo_blue "检查网卡速率..."
    
    local has_issue=0
    
    for nic in $(ls /sys/class/net/ | grep -v lo); do
        if [ -d "/sys/class/net/$nic/device" ]; then
            speed=$(ethtool $nic 2>/dev/null | grep "Speed:" | awk '{print $2}' | sed 's/Mb\/s//')
            if [ ! -z "$speed" ] && [ "$speed" != "Unknown!" ]; then
                echo "   $nic: ${speed}Mb/s"
                
                if [[ "$nic" == *"cluster"* ]] || [[ "$nic" == *"bond0"* ]]; then
                    if [ "$speed" -lt 10000 ]; then
                        echo_warn "   集群网卡 $nic 速率低于10000Mb/s要求"
                        has_issue=1
                    fi
                elif [ "$speed" -lt 1000 ]; then
                    echo_warn "   业务网卡 $nic 速率低于1000Mb/s要求"
                    has_issue=1
                fi
            fi
        fi
    done
    
    if [ $has_issue -eq 0 ]; then
        CHECK_STATUS["network_speed"]="PASS"
        echo -e "${GREEN}✓${NC} 网卡速率: 符合要求"
    else
        CHECK_STATUS["network_speed"]="WARN"
        echo -e "${YELLOW}⚠${NC} 网卡速率: 部分网卡速率不满足要求"
        echo_warn "此项需要硬件支持，无法自动修复"
    fi
}

# 3. 检查并修复DNS
check_and_fix_dns() {
    echo_blue "检查DNS配置..."
    
    local dns_servers=$(grep "nameserver" /etc/resolv.conf | awk '{print $2}' | tr '\n' ' ')
    local reachable=0
    local reachable_dns=""
    
    for dns in $dns_servers; do
        if ping -c 1 -W 1 $dns &>/dev/null; then
            reachable=1
            reachable_dns=$dns
            break
        fi
    done
    
    if [ $reachable -eq 1 ]; then
        CHECK_STATUS["dns"]="PASS"
        echo -e "${GREEN}✓${NC} DNS配置: 正常 ($reachable_dns 可达)"
    else
        CHECK_STATUS["dns"]="FAIL"
        echo -e "${RED}✗${NC} DNS配置: 当前DNS服务器不可达 ($dns_servers)"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            local local_ip=$(hostname -I | awk '{print $1}')
            echo ""
            echo "   建议配置DNS为本机IP: $local_ip"
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
            read -p "是否配置DNS为本机IP? [Y/n]: " answer
    fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                echo "nameserver $local_ip" > /etc/resolv.conf
                echo_info "DNS已配置为: $local_ip"
                CHECK_STATUS["dns"]="FIXED"
            fi
        fi
    fi
}

# 4. 检查并修复NetworkManager
check_and_fix_network_service() {
    echo_blue "检查网络服务..."
    
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "$NAME" == *"CentOS"* ]] || [[ "$NAME" == *"Red Hat"* ]]; then
            if [[ "$VERSION_ID" == "7"* ]]; then
                local nm_status=$(systemctl is-active NetworkManager 2>/dev/null || echo "inactive")
                
                if [ "$nm_status" = "active" ]; then
                    CHECK_STATUS["network_service"]="FAIL"
                    echo -e "${RED}✗${NC} 网络服务: NetworkManager运行中 (CentOS/RHEL 7需要关闭)"
                    
                    if [[ -z "$CHECK_ONLY" ]]; then
                        echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
                        read -p "是否关闭NetworkManager并启用network服务? [Y/n]: " answer
    fi
                        if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                            systemctl stop NetworkManager
                            systemctl disable NetworkManager
                            systemctl enable network 2>/dev/null || true
                            systemctl restart network 2>/dev/null || true
                            echo_info "NetworkManager已关闭，network服务已启用"
                            CHECK_STATUS["network_service"]="FIXED"
                        fi
                    fi
                else
                    CHECK_STATUS["network_service"]="PASS"
                    echo -e "${GREEN}✓${NC} 网络服务: 配置正确"
                fi
                return
            fi
        fi
    fi
    
    CHECK_STATUS["network_service"]="PASS"
    echo -e "${GREEN}✓${NC} 网络服务: 无需调整"
}

# 5. 检查并修复Swap
check_and_fix_swap() {
    echo_blue "检查Swap分区..."
    
    local swap_total=$(free -m | grep Swap | awk '{print $2}')
    
    if [ "$swap_total" -eq 0 ]; then
        CHECK_STATUS["swap"]="PASS"
        echo -e "${GREEN}✓${NC} Swap分区: 已关闭"
    else
        CHECK_STATUS["swap"]="FAIL"
        echo -e "${RED}✗${NC} Swap分区: 未关闭 (${swap_total}MB)"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
            read -p "是否关闭Swap分区? [Y/n]: " answer
    fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                swapoff -a
                sed -i 's/.*swap.*/#&/' /etc/fstab
                echo_info "Swap分区已关闭"
                CHECK_STATUS["swap"]="FIXED"
            fi
        fi
    fi
}

# 6. 检查并修复SELinux
check_and_fix_selinux() {
    echo_blue "检查SELinux..."
    
    if [ -f /etc/selinux/config ]; then
        local selinux_status=$(getenforce 2>/dev/null || echo "Disabled")
        local selinux_config=$(grep "^SELINUX=" /etc/selinux/config | cut -d= -f2)
        
        if [ "$selinux_status" = "Disabled" ] || [ "$selinux_config" = "disabled" ]; then
            CHECK_STATUS["selinux"]="PASS"
            echo -e "${GREEN}✓${NC} SELinux: 已禁用"
        else
            CHECK_STATUS["selinux"]="FAIL"
            echo -e "${RED}✗${NC} SELinux: 未禁用 (当前:$selinux_status)"
            
            if [[ -z "$CHECK_ONLY" ]]; then
                echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
                read -p "是否禁用SELinux? [Y/n]: " answer
    fi
                if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                    setenforce 0 2>/dev/null || true
                    sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config
                    echo_info "SELinux已设置为disabled (重启后生效)"
                    CHECK_STATUS["selinux"]="FIXED"
                fi
            fi
        fi
    else
        CHECK_STATUS["selinux"]="PASS"
        echo -e "${GREEN}✓${NC} SELinux: 无配置文件"
    fi
}

# 7. 检查并修复I/O调度
check_and_fix_io_scheduler() {
    echo_blue "检查磁盘I/O调度算法..."
    
    local has_issue=0
    local issue_disks=""
    
    for disk in $(lsblk -d -o NAME,TYPE | grep disk | awk '{print $1}'); do
        scheduler_path="/sys/block/$disk/queue/scheduler"
        if [ -f "$scheduler_path" ]; then
            current=$(cat $scheduler_path | grep -o '\[.*\]' | tr -d '[]')
            
            if [[ "$disk" == nvme* ]]; then
                if [ "$current" != "none" ]; then
                    echo -e "${YELLOW}⚠${NC} $disk: 当前调度算法 $current (NVMe建议使用none)"
                    has_issue=1
                    issue_disks="$issue_disks $disk:none"
                else
                    echo "   $disk: $current (正确)"
                fi
            else
                if [ "$current" != "deadline" ]; then
                    echo -e "${YELLOW}⚠${NC} $disk: 当前调度算法 $current (建议使用deadline)"
                    has_issue=1
                    issue_disks="$issue_disks $disk:deadline"
                else
                    echo "   $disk: $current (正确)"
                fi
            fi
        fi
    done
    
    if [ $has_issue -eq 0 ]; then
        CHECK_STATUS["io_scheduler"]="PASS"
        echo -e "${GREEN}✓${NC} I/O调度: 所有磁盘配置正确"
    else
        CHECK_STATUS["io_scheduler"]="FAIL"
        echo -e "${RED}✗${NC} I/O调度: 部分磁盘需要调整"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
            read -p "是否调整I/O调度算法? [Y/n]: " answer
    fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                for item in $issue_disks; do
                    disk=$(echo $item | cut -d: -f1)
                    scheduler=$(echo $item | cut -d: -f2)
                    echo $scheduler > /sys/block/$disk/queue/scheduler 2>/dev/null || true
                    echo_info "磁盘 $disk 调度算法已设置为 $scheduler"
                done
                CHECK_STATUS["io_scheduler"]="FIXED"
            fi
        fi
    fi
}

# 8. 检查并修复auditd
check_and_fix_auditd() {
    echo_blue "检查auditd服务..."
    
    if [[ -f /etc/os-release ]] && grep -qi "kylin" /etc/os-release; then
        local auditd_status=$(systemctl is-active auditd 2>/dev/null || echo "inactive")
        
        if [ "$auditd_status" = "active" ]; then
            CHECK_STATUS["auditd"]="FAIL"
            echo -e "${RED}✗${NC} Auditd: 运行中 (麒麟系统建议关闭)"
            
            if [[ -z "$CHECK_ONLY" ]]; then
                echo ""
    # 在自动确认模式下自动确认
    if [ "$AUTO_CONFIRM" = "1" ]; then
        answer="y"
        echo "是否...? [Y/n]: [自动确认: Y]"
    else
                read -p "是否关闭auditd服务? [Y/n]: " answer
    fi
                if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                    systemctl stop auditd
                    systemctl disable auditd
                    echo_info "auditd服务已关闭"
                    CHECK_STATUS["auditd"]="FIXED"
                fi
            fi
        else
            CHECK_STATUS["auditd"]="PASS"
            echo -e "${GREEN}✓${NC} Auditd: 已关闭"
        fi
    else
        CHECK_STATUS["auditd"]="SKIP"
        echo -e "${GREEN}✓${NC} Auditd: 非麒麟系统，跳过检查"
    fi
}

# 9. 检查并修复主机名
check_and_fix_hostname() {
    echo_blue "检查主机名..."
    
    local hostname=$(hostname)
    
    if [[ "$hostname" =~ [A-Z] ]]; then
        CHECK_STATUS["hostname"]="FAIL"
        echo -e "${RED}✗${NC} 主机名: $hostname (包含大写字母)"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            echo "   主机名只能包含小写字母、数字和连字符"
            read -p "是否修改主机名? [y/N]: " answer
            if [[ "$answer" == "y" ]] || [[ "$answer" == "Y" ]]; then
                read -p "请输入新的主机名: " new_hostname
                if [[ ! "$new_hostname" =~ [^a-z0-9\-\.] ]] && [[ ! "$new_hostname" =~ [A-Z] ]]; then
                    hostnamectl set-hostname $new_hostname
                    echo_info "主机名已修改为: $new_hostname"
                    CHECK_STATUS["hostname"]="FIXED"
                else
                    echo_error "主机名格式不正确"
                fi
            fi
        fi
    elif [[ "$hostname" =~ [^a-z0-9\-\.] ]]; then
        CHECK_STATUS["hostname"]="FAIL"
        echo -e "${RED}✗${NC} 主机名: $hostname (包含特殊字符)"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            read -p "是否修改主机名? [y/N]: " answer
            if [[ "$answer" == "y" ]] || [[ "$answer" == "Y" ]]; then
                read -p "请输入新的主机名: " new_hostname
                if [[ ! "$new_hostname" =~ [^a-z0-9\-\.] ]] && [[ ! "$new_hostname" =~ [A-Z] ]]; then
                    hostnamectl set-hostname $new_hostname
                    echo_info "主机名已修改为: $new_hostname"
                    CHECK_STATUS["hostname"]="FIXED"
                else
                    echo_error "主机名格式不正确"
                fi
            fi
        fi
    else
        CHECK_STATUS["hostname"]="PASS"
        echo -e "${GREEN}✓${NC} 主机名: $hostname (格式正确)"
    fi
}

# 10. 检查并安装必要软件包
check_and_fix_packages() {
    echo_blue "检查必要软件包..."
    
    # 定义软件包映射（命令名:实际包名）
    declare -A pkg_map
    pkg_map["conntrack"]="conntrack-tools"
    pkg_map["vim"]="vim-enhanced"
    pkg_map["tcpdump"]="tcpdump"
    pkg_map["iostat"]="sysstat"  # iostat 是 sysstat 包提供的命令
    pkg_map["ifconfig"]="net-tools"  # ifconfig 是 net-tools 包提供的命令
    pkg_map["nslookup"]="bind-utils"  # nslookup 是 bind-utils 包提供的命令
    pkg_map["lsof"]="lsof"
    pkg_map["rsync"]="rsync"
    
    local missing_packages=""
    local missing_display=""
    local installed_count=0
    local total_count=0
    
    echo_info "开始检查各软件包安装状态..."
    echo ""
    
    # 按顺序检查每个软件包
    for cmd in conntrack vim tcpdump iostat ifconfig nslookup lsof rsync; do
        if [[ -n "${pkg_map[$cmd]}" ]]; then
            pkg="${pkg_map[$cmd]}"
            total_count=$((total_count + 1))
            
            echo -n "  检查 $cmd (包名: $pkg) ... "
            
            # 检查命令是否存在
            if command -v $cmd &>/dev/null; then
                echo -e "${GREEN}[已安装]${NC}"
                installed_count=$((installed_count + 1))
            else
                # 再次检查包是否安装
                if rpm -q $pkg &>/dev/null 2>&1; then
                    echo -e "${YELLOW}[包已安装但命令不可用]${NC}"
                    installed_count=$((installed_count + 1))
                else
                    echo -e "${RED}[未安装]${NC}"
                    missing_packages="$missing_packages $pkg"
                    missing_display="$missing_display $cmd"
                fi
            fi
        fi
    done
    
    echo ""
    
    if [ -z "$missing_packages" ]; then
        CHECK_STATUS["packages"]="PASS"
        echo -e "${GREEN}✓${NC} 软件包检查结果: 所有必要软件包已安装 (${installed_count}/${total_count})"
    else
        CHECK_STATUS["packages"]="FAIL"
        echo -e "${RED}✗${NC} 软件包检查结果: 有 $((total_count - installed_count)) 个软件包未安装"
        echo -e "   缺失的命令:${RED}$missing_display${NC}"
        echo -e "   需要安装的软件包:${RED}$missing_packages${NC}"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            # 在自动确认模式下自动安装
            if [ "$AUTO_CONFIRM" = "1" ]; then
                answer="y"
                echo "是否安装缺失的软件包? [Y/n]: [自动确认: Y]"
            else
                read -p "是否安装缺失的软件包? [Y/n]: " answer
            fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                echo_info "正在安装软件包..."
                if command -v yum &>/dev/null; then
                    if yum install -y $missing_packages 2>/dev/null; then
                        echo_info "软件包安装完成"
                        CHECK_STATUS["packages"]="FIXED"
                    else
                        echo_error "部分软件包安装失败，可能需要配置YUM源"
                    fi
                elif command -v apt-get &>/dev/null; then
                    apt-get update && apt-get install -y $missing_packages
                    CHECK_STATUS["packages"]="FIXED"
                fi
            fi
        fi
    fi
}

# 11. 检查并移除容器软件
check_and_fix_containers() {
    echo_blue "检查容器软件..."
    
    local containers=$(rpm -qa 2>/dev/null | grep -E "docker|podman" | wc -l)
    
    if [ $containers -eq 0 ]; then
        CHECK_STATUS["containers"]="PASS"
        echo -e "${GREEN}✓${NC} 容器软件: 未安装docker/podman"
    else
        CHECK_STATUS["containers"]="FAIL"
        echo -e "${RED}✗${NC} 容器软件: 发现${containers}个容器相关包"
        rpm -qa | grep -E "docker|podman" | sed 's/^/   /'
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            read -p "是否卸载docker和podman? [Y/n]: " answer
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                echo_info "正在卸载容器软件..."
                rpm -e $(rpm -qa | grep -E "docker|podman") --nodeps 2>/dev/null || true
                echo_info "容器软件已卸载"
                CHECK_STATUS["containers"]="FIXED"
            fi
        fi
    fi
}

# 12. 检查并修复/tmp权限
check_and_fix_tmp() {
    echo_blue "检查/tmp目录权限..."
    
    local perms=$(stat -c %a /tmp)
    
    if [ "$perms" = "777" ] || [ "$perms" = "1777" ]; then
        CHECK_STATUS["tmp"]="PASS"
        echo -e "${GREEN}✓${NC} /tmp权限: 正确 ($perms)"
    else
        CHECK_STATUS["tmp"]="FAIL"
        echo -e "${RED}✗${NC} /tmp权限: 不正确 (当前:$perms, 应为:777)"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            read -p "是否修正/tmp权限为777? [Y/n]: " answer
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                chmod 777 /tmp
                
                # 检查fstab
                if grep -q "/tmp" /etc/fstab; then
                    sed -i '/\/tmp/ s/,nosuid//g; /\/tmp/ s/,noexec//g' /etc/fstab
                    echo_info "/tmp权限已设置为777，并移除fstab中的nosuid/noexec选项"
                else
                    echo_info "/tmp权限已设置为777"
                fi
                CHECK_STATUS["tmp"]="FIXED"
            fi
        fi
    fi
}

# 13. 检查并创建kubernetes目录
check_and_fix_kubernetes() {
    echo_blue "检查kubernetes目录..."
    
    if [ -d "/etc/kubernetes/manifests" ]; then
        local perms=$(stat -c %a /etc/kubernetes/manifests)
        if [ "$perms" = "755" ]; then
            CHECK_STATUS["kubernetes"]="PASS"
            echo -e "${GREEN}✓${NC} Kubernetes目录: 存在且权限正确"
        else
            CHECK_STATUS["kubernetes"]="FAIL"
            echo -e "${YELLOW}⚠${NC} Kubernetes目录: 权限不正确 (当前:$perms, 应为:755)"
            
            if [[ -z "$CHECK_ONLY" ]]; then
                echo ""
                # 在自动确认模式下自动修正
                if [ "$AUTO_CONFIRM" = "1" ]; then
                    answer="y"
                    echo "是否修正权限为755? [Y/n]: [自动确认: Y]"
                else
                    read -p "是否修正权限为755? [Y/n]: " answer
                fi
                if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                    chmod 755 /etc/kubernetes/manifests
                    echo_info "权限已修正为755"
                    CHECK_STATUS["kubernetes"]="FIXED"
                fi
            fi
        fi
    else
        CHECK_STATUS["kubernetes"]="FAIL"
        echo -e "${RED}✗${NC} Kubernetes目录: 不存在"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            # 在自动确认模式下自动创建
            if [ "$AUTO_CONFIRM" = "1" ]; then
                answer="y"
                echo "是否创建/etc/kubernetes/manifests目录? [Y/n]: [自动确认: Y]"
            else
                read -p "是否创建/etc/kubernetes/manifests目录? [Y/n]: " answer
            fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                mkdir -p /etc/kubernetes/manifests
                chmod 755 /etc/kubernetes/manifests
                echo_info "目录已创建，权限755"
                CHECK_STATUS["kubernetes"]="FIXED"
            fi
        fi
    fi
}

# 14. 检查并关闭virbr0
check_and_fix_virbr0() {
    echo_blue "检查virbr0网卡..."
    
    if ip link show virbr0 &>/dev/null; then
        CHECK_STATUS["virbr0"]="FAIL"
        echo -e "${RED}✗${NC} virbr0网卡: 存在"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            read -p "是否关闭libvirtd服务并删除virbr0? [Y/n]: " answer
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                systemctl stop libvirtd 2>/dev/null || true
                systemctl disable libvirtd 2>/dev/null || true
                echo_info "libvirtd服务已关闭"
                CHECK_STATUS["virbr0"]="FIXED"
            fi
        fi
    else
        CHECK_STATUS["virbr0"]="PASS"
        echo -e "${GREEN}✓${NC} virbr0网卡: 不存在"
    fi
}

# 15. 检查CPU AVX
check_cpu_avx() {
    echo_blue "检查CPU AVX指令集..."
    
    if grep -o 'avx' /proc/cpuinfo &>/dev/null; then
        CHECK_STATUS["cpu_avx"]="PASS"
        echo -e "${GREEN}✓${NC} CPU AVX: 支持AVX指令集"
    else
        CHECK_STATUS["cpu_avx"]="WARN"
        echo -e "${YELLOW}⚠${NC} CPU AVX: 不支持AVX指令集"
        echo "   注意: MongoDB 5.0及以上版本需要AVX支持"
    fi
}

# 16. 检查并配置用户限制
check_and_fix_limits() {
    echo_blue "检查用户资源限制..."
    
    if grep -q "oracle soft nproc" /etc/security/limits.conf; then
        CHECK_STATUS["limits"]="PASS"
        echo -e "${GREEN}✓${NC} 用户限制: Oracle用户限制已配置"
    else
        CHECK_STATUS["limits"]="FAIL"
        echo -e "${RED}✗${NC} 用户限制: Oracle用户限制未配置"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            # 在自动确认模式下自动添加
            if [ "$AUTO_CONFIRM" = "1" ]; then
                answer="y"
                echo "是否添加Oracle用户资源限制? [Y/n]: [自动确认: Y]"
            else
                read -p "是否添加Oracle用户资源限制? [Y/n]: " answer
            fi
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                cat >> /etc/security/limits.conf << EOF

# Oracle user limits
oracle soft nproc 65536
oracle hard nproc 65536
oracle soft nofile 65536
oracle hard nofile 65536

# Oracle11g user limits
oracle11g soft nproc 65536
oracle11g hard nproc 65536
oracle11g soft nofile 65536
oracle11g hard nofile 65536
EOF
                echo_info "Oracle用户资源限制已添加"
                echo_warn "注意: nproc限制修改需要重启节点才能生效"
                CHECK_STATUS["limits"]="FIXED"
            fi
        fi
    fi
}

# 17. 调整nproc配置参数
check_and_fix_nproc_config() {
    echo_blue "检查nproc配置参数..."
    
    local limits_file="/etc/security/limits.conf"
    local backup_file="${limits_file}.bak.$(date +%Y%m%d_%H%M%S)"
    
    # 定义需要的配置内容
    local required_config="# System-wide limits
* soft nproc 16384
* hard nproc 16384
* soft nofile 65536
* hard nofile 65536
* soft stack 32768
* hard stack 32768
* soft core 2097152
* hard core 2097152

# Oracle user limits
oracle soft nproc 65536
oracle hard nproc 65536
oracle soft nofile 65536
oracle hard nofile 65536
oracle soft stack 65536
oracle hard stack 65536

# Oracle11g user limits
oracle11g soft nproc 65536
oracle11g hard nproc 65536
oracle11g soft nofile 65536
oracle11g hard nofile 65536
oracle11g soft stack 65536
oracle11g hard stack 65536"
    
    # 检查是否已有正确的配置
    local need_update=0
    
    # 检查关键配置项是否存在
    if ! grep -q "^\* soft nproc 16384" "$limits_file" 2>/dev/null || \
       ! grep -q "^\* hard nproc 16384" "$limits_file" 2>/dev/null || \
       ! grep -q "^\* soft nofile 65536" "$limits_file" 2>/dev/null || \
       ! grep -q "^oracle soft nproc 65536" "$limits_file" 2>/dev/null || \
       ! grep -q "^oracle11g soft nproc 65536" "$limits_file" 2>/dev/null; then
        need_update=1
    fi
    
    if [ $need_update -eq 0 ]; then
        CHECK_STATUS["nproc_config"]="PASS"
        echo -e "${GREEN}✓${NC} nproc配置: 已正确配置"
    else
        CHECK_STATUS["nproc_config"]="FAIL"
        echo -e "${RED}✗${NC} nproc配置: 需要调整配置"
        
        if [[ -z "$CHECK_ONLY" ]]; then
            echo ""
            # 在自动确认模式下自动修改
            if [ "$AUTO_CONFIRM" = "1" ]; then
                answer="y"
                echo "是否调整nproc配置参数? [Y/n]: [自动确认: Y]"
            else
                read -p "是否调整nproc配置参数? [Y/n]: " answer
            fi
            
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                # 备份原文件
                cp "$limits_file" "$backup_file"
                echo_info "原文件已备份到: $backup_file"
                
                # 保留注释行，删除所有非注释配置
                grep "^#" "$limits_file" > "${limits_file}.tmp" 2>/dev/null || true
                
                # 添加新配置
                {
                    cat "${limits_file}.tmp"
                    echo ""
                    echo "$required_config"
                } > "$limits_file"
                
                # 清理临时文件
                rm -f "${limits_file}.tmp"
                
                echo_info "nproc配置已更新"
                echo_warn "注意: 资源限制修改需要重新登录或重启节点才能生效"
                CHECK_STATUS["nproc_config"]="FIXED"
            fi
        fi
    fi
}

# 18. 可选配置RAID
check_and_configure_raid() {
    # 临时禁用错误退出，因为某些磁盘检查可能失败
    local old_errexit=$(set +o | grep errexit)
    set +e
    
    echo_blue "可选配置RAID..."
    
    # 检查是否为只检查模式
    if [[ -n "$CHECK_ONLY" ]]; then
        echo_info "跳过RAID配置（只检查模式）"
        CHECK_STATUS["raid"]="SKIP"
        eval "$old_errexit"
        return 0
    fi
    
    # 检查mdadm是否安装
    if ! command -v mdadm &>/dev/null; then
        echo_warn "mdadm未安装，正在安装..."
        if yum install -y mdadm &>/dev/null 2>&1; then
            echo_info "mdadm安装成功"
        else
            echo_error "mdadm安装失败，跳过RAID配置"
            CHECK_STATUS["raid"]="SKIP"
            eval "$old_errexit"
            return 0
        fi
    fi
    
    # 检查现有的RAID阵列
    echo ""
    echo_info "检查现有RAID阵列..."
    local existing_raids=$(cat /proc/mdstat 2>/dev/null | grep "^md" | wc -l)
    
    if [ "$existing_raids" -gt 0 ]; then
        echo ""
        echo "======================================================================================================"
        echo "                                        现有RAID阵列信息                                             "
        echo "======================================================================================================"
        
        # 显示/proc/mdstat信息
        echo "RAID状态概览:"
        cat /proc/mdstat | grep -E "^md|blocks|resync" | while read line; do
            echo "  $line"
        done
        
        echo ""
        echo "详细信息:"
        # 获取所有md设备
        for md in $(ls /dev/md* 2>/dev/null | grep -E "md[0-9]+$"); do
            if [ -b "$md" ]; then
                echo ""
                echo "设备: $md"
                echo "----------------------------------------"
                
                # 显示RAID级别和状态
                mdadm --detail "$md" 2>/dev/null | grep -E "Raid Level|Array Size|Used Dev Size|State|Active Devices|Working Devices|Failed Devices" | while read line; do
                    echo "  $line"
                done
                
                # 显示成员磁盘
                echo "  成员磁盘:"
                # 从"Number Major Minor"开始解析设备列表
                mdadm --detail "$md" 2>/dev/null | awk '
                    /Number   Major   Minor   RaidDevice State/ { found=1; next }
                    found && /^[[:space:]]*$/ { exit }
                    found && /^[[:space:]]*[0-9]/ {
                        # 最后一列是设备名，倒数第二列是状态
                        device = $NF
                        state = $(NF-1)
                        role = $4
                        if (device ~ /^\/dev\//) {
                            if (state == "sync") state = "active sync"
                            printf "    - %s (Device %s, %s)\n", device, role, state
                        }
                    }
                ' 
                
                # 检查挂载情况
                local mount_point=$(mount | grep "$md" | awk '{print $3}')
                if [ -n "$mount_point" ]; then
                    echo "  挂载点: $mount_point"
                    df -h "$md" | tail -1 | awk '{print "  使用情况: " $2 " 总容量, " $3 " 已使用, " $4 " 可用, " $5 " 使用率"}'
                else
                    echo "  挂载点: 未挂载"
                fi
            fi
        done
        
        echo "======================================================================================================"
        echo ""
        echo -e "${GREEN}发现 $existing_raids 个现有RAID阵列${NC}"
        echo ""
    else
        echo_info "没有发现现有的RAID阵列"
    fi
    
    echo ""
    echo_info "正在扫描可用磁盘资源..."
    echo ""
    
    # 获取所有磁盘信息
    local disk_count=0
    declare -a disk_names
    declare -a disk_paths
    declare -a disk_sizes
    declare -a disk_types
    declare -a disk_raid_status
    
    # 扫描所有磁盘设备 - 添加错误处理
    local disk_list=$(lsblk -d -n -o NAME 2>/dev/null | grep -E '^sd|^vd|^nvme' || true)
    
    # 如果没有找到磁盘
    if [ -z "$disk_list" ]; then
        echo_warn "未发现可用的磁盘设备"
        CHECK_STATUS["raid"]="SKIP"
        eval "$old_errexit"
        return 0
    fi
    
    for disk in $disk_list; do
        disk_names[$disk_count]="$disk"
        disk_paths[$disk_count]="/dev/$disk"
        
        # 获取磁盘大小 - 添加错误处理
        local size_bytes=$(lsblk -b -d -n -o SIZE "/dev/$disk" 2>/dev/null || echo "0")
        if [ -n "$size_bytes" ] && [ "$size_bytes" != "0" ]; then
            disk_sizes[$disk_count]=$(echo "$size_bytes" | awk '{printf "%.1f GB", $1/1024/1024/1024}')
        else
            disk_sizes[$disk_count]="未知"
        fi
        
        # 获取磁盘类型
        if [[ "$disk" =~ ^nvme ]]; then
            disk_types[$disk_count]="NVMe"
        elif [[ "$disk" =~ ^vd ]]; then
            disk_types[$disk_count]="Virtual"
        else
            # 检查是否为SSD
            local rotational=$(cat /sys/block/$disk/queue/rotational 2>/dev/null || echo "1")
            if [ "$rotational" = "0" ]; then
                disk_types[$disk_count]="SSD"
            else
                disk_types[$disk_count]="HDD"
            fi
        fi
        
        # 检查磁盘的RAID状态 - 改进的检测逻辑
        local is_raid_member="否"
        local raid_details=""
        
        # 方法1: 使用mdadm --examine检查磁盘超级块
        local examine_output=$(mdadm --examine "/dev/$disk" 2>/dev/null)
        if [ -n "$examine_output" ]; then
            # 获取RAID级别
            local raid_level=$(echo "$examine_output" | grep "Raid Level" | awk -F: '{print $2}' | xargs)
            # 获取阵列UUID
            local array_uuid=$(echo "$examine_output" | grep "Array UUID" | awk -F: '{print $2}' | xargs)
            # 获取设备角色
            local dev_role=$(echo "$examine_output" | grep "Device Role" | awk -F: '{print $2}' | xargs)
            
            if [ -n "$raid_level" ] || [ -n "$array_uuid" ]; then
                is_raid_member="是"
                if [ -n "$raid_level" ]; then
                    raid_details="RAID${raid_level}"
                fi
                if [ -n "$dev_role" ] && [ "$dev_role" != "Active device" ]; then
                    raid_details="${raid_details}($dev_role)"
                fi
            fi
        fi
        
        # 方法2: 检查分区是否被RAID使用
        if [ "$is_raid_member" = "否" ]; then
            # 检查磁盘的所有分区
            for partition in $(ls /dev/${disk}* 2>/dev/null | grep -E "${disk}[0-9]+$"); do
                local part_examine=$(mdadm --examine "$partition" 2>/dev/null | grep "Array UUID")
                if [ -n "$part_examine" ]; then
                    is_raid_member="是(分区)"
                    break
                fi
            done
        fi
        
        # 方法3: 从/proc/mdstat反向查找
        if [ "$is_raid_member" = "否" ] && [ -f /proc/mdstat ]; then
            if grep -q "\b$disk\b" /proc/mdstat 2>/dev/null; then
                is_raid_member="是"
                # 找出属于哪个md设备
                local md_name=$(grep "\b$disk\b" /proc/mdstat | awk '{print $1}')
                if [ -n "$md_name" ]; then
                    raid_details="($md_name)"
                fi
            fi
        fi
        
        # 设置最终状态
        if [ "$is_raid_member" = "是" ]; then
            if [ -n "$raid_details" ]; then
                disk_raid_status[$disk_count]="是-$raid_details"
            else
                disk_raid_status[$disk_count]="是"
            fi
        else
            disk_raid_status[$disk_count]="否"
        fi
        
        ((disk_count++))
    done
    
    # 检查磁盘分区情况
    echo ""
    echo_info "检查磁盘分区情况..."
    declare -a disks_with_partitions
    declare -a partition_details
    local partition_count=0
    
    for ((i=0; i<$disk_count; i++)); do
        local disk_name="${disk_names[$i]}"
        local disk_path="${disk_paths[$i]}"
        
        # 跳过已经加入RAID的磁盘
        if [[ "${disk_raid_status[$i]}" != "否" ]]; then
            continue
        fi
        
        # 检查是否有分区
        local partitions=$(lsblk -n -o NAME,TYPE "$disk_path" 2>/dev/null | grep -c "part" || true)
        
        if [ "$partitions" -gt 0 ]; then
            disks_with_partitions[$partition_count]="$i"
            # 获取分区详情
            local part_info=$(lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT "$disk_path" 2>/dev/null | grep -E "├|└" || true)
            partition_details[$partition_count]="$part_info"
            ((partition_count++))
        fi
    done
    
    # 如果发现有分区的磁盘，询问是否清除
    if [ "$partition_count" -gt 0 ]; then
        echo ""
        echo -e "${YELLOW}发现以下磁盘存在分区：${NC}"
        echo "========================================================================================================"
        
        for ((i=0; i<$partition_count; i++)); do
            local disk_idx="${disks_with_partitions[$i]}"
            echo ""
            echo "磁盘: ${disk_names[$disk_idx]} (${disk_paths[$disk_idx]}) - ${disk_sizes[$disk_idx]}"
            echo "分区信息:"
            echo "${partition_details[$i]}" | while IFS= read -r line; do
                echo "  $line"
            done
        done
        
        echo "========================================================================================================"
        echo ""
        echo -e "${YELLOW}警告：清除分区将删除磁盘上的所有数据！${NC}"
        echo "请选择需要清除分区的磁盘（用于创建RAID）"
        echo "输入磁盘序号（从0开始），多个用逗号分隔，如: 0,1,2"
        echo "输入 'all' 清除所有有分区的磁盘"
        echo "输入 'skip' 或直接回车跳过清除分区"
        echo -n "请输入: "
        
        local clear_choice
        if read -t 30 clear_choice; then
            if [ -n "$clear_choice" ] && [ "$clear_choice" != "skip" ]; then
                declare -a disks_to_clear
                local clear_count=0
                
                if [ "$clear_choice" = "all" ]; then
                    # 清除所有有分区的磁盘
                    for ((i=0; i<$partition_count; i++)); do
                        disks_to_clear[$clear_count]="${disks_with_partitions[$i]}"
                        ((clear_count++))
                    done
                else
                    # 解析选择的磁盘
                    IFS=',' read -ra selected_clear <<< "$clear_choice"
                    for idx in "${selected_clear[@]}"; do
                        idx=$(echo $idx | tr -d ' ')
                        if [[ "$idx" =~ ^[0-9]+$ ]]; then
                            # 查找对应的磁盘索引
                            for ((i=0; i<$partition_count; i++)); do
                                if [ "${disks_with_partitions[$i]}" = "$idx" ]; then
                                    disks_to_clear[$clear_count]="$idx"
                                    ((clear_count++))
                                    break
                                fi
                            done
                        fi
                    done
                fi
                
                # 执行清除操作
                if [ "$clear_count" -gt 0 ]; then
                    echo ""
                    echo_warn "即将清除以下磁盘的分区："
                    for disk_idx in "${disks_to_clear[@]}"; do
                        echo "  - ${disk_names[$disk_idx]} (${disk_paths[$disk_idx]})"
                    done
                    
                    echo ""
                    echo -e "${RED}最后确认：是否继续清除？输入 'yes' 确认，其他任意键取消${NC}"
                    echo -n ": "
                    
                    local confirm_clear
                    if read -t 10 confirm_clear && [ "$confirm_clear" = "yes" ]; then
                        echo ""
                        echo_info "开始清除分区..."
                        
                        for disk_idx in "${disks_to_clear[@]}"; do
                            local disk_path="${disk_paths[$disk_idx]}"
                            echo -n "清除 ${disk_names[$disk_idx]} 的分区..."
                            
                            # 卸载该磁盘的所有分区
                            for part in $(lsblk -n -o NAME "$disk_path" 2>/dev/null | grep -v "^${disk_names[$disk_idx]}$" | sed 's/[├└─]//g'); do
                                umount "/dev/$part" 2>/dev/null || true
                            done
                            
                            # 清除分区表
                            dd if=/dev/zero of="$disk_path" bs=512 count=1 2>/dev/null
                            
                            # 通知内核重新读取分区表
                            partprobe "$disk_path" 2>/dev/null || true
                            
                            echo " 完成"
                        done
                        
                        echo ""
                        echo_info "分区清除完成"
                    else
                        echo_info "取消清除分区"
                    fi
                fi
            else
                echo_info "跳过分区清除"
            fi
        else
            echo ""
            echo_warn "输入超时，跳过分区清除"
        fi
    fi
    
    # 显示磁盘信息表格
    echo ""
    echo "========================================================================================================"
    printf "序号   磁盘名称        路径                       大小              类型        已做RAID\n"
    echo "======================================================================================================="
    
    for ((i=0; i<$disk_count; i++)); do
        # 构建对齐的输出行，补偿中文字符的宽度差异
        # 中文字符占2个显示宽度，英文字符占1个显示宽度
        local line=""
        
        # 序号 - "序号"占4个显示宽度，需要对齐
        line=$(printf "%-7s" "$i")
        
        # 磁盘名称 - "磁盘名称"占8个显示宽度
        line="${line}$(printf "%-16s" "${disk_names[$i]}")"
        
        # 路径 - "路径"占4个显示宽度，但只算2个字符，需要补偿2个空格
        # 标题中"路径"后有额外3个空格，所以数据也要对应
        line="${line}$(printf "%-27s" "${disk_paths[$i]}")"
        # 补偿中文字符宽度差，但减少3个空格让数据左移
        # line="${line}  "  # 原本2个补偿，现在去掉，相当于左移2格
        # 为了左移3格，我们需要在前面的printf中减少宽度
        
        # 大小 - 数据向左移3格（相对于标题）
        line="${line}$(printf "%-18s" "${disk_sizes[$i]}")"
        # 不添加补偿空格，让数据左移
        
        # 类型 - 数据向左移3格（相对于标题）
        line="${line}$(printf "%-12s" "${disk_types[$i]}")"
        # 不添加补偿空格，让数据左移
        
        # 已做RAID - 数据向左移3格（相对于标题）
        line="${line}${disk_raid_status[$i]}"
        
        echo "$line"
    done
    echo "========================================================================================================"
    
    echo ""
    # 询问是否需要创建RAID
    while true; do
        echo -e "${YELLOW}现在是否需要创建RAID，1、需要创建；2、暂不需要，跳过该环节，请输入1或2${NC}"
        echo -n ": "
        
        # 使用不同的变量捕获read的退出状态
        if read -t 30 raid_choice; then
            # 用户输入了内容（可能为空）
            if [ -z "$raid_choice" ]; then
                # 用户只按了回车，没有输入
                echo ""
                echo_warn "未输入选择，请输入1或2"
                continue
            fi
        else
            # read超时或出错
            echo ""
            echo_warn "输入超时，默认跳过RAID配置"
            raid_choice="2"
        fi
        
        if [ "$raid_choice" = "2" ]; then
            echo_info "跳过RAID配置"
            CHECK_STATUS["raid"]="SKIP"
            eval "$old_errexit"
            return 0
        elif [ "$raid_choice" = "1" ]; then
            break
        else
            echo_error "输入错误，请重新输入"
            echo ""
        fi
    done
    
    # 选择磁盘 - 添加循环直到输入正确
    while true; do
        echo ""
        echo -e "${YELLOW}请选择需要用哪些盘做RAID${NC}"
        echo "输入磁盘序号（从0开始），单块盘输入如: 1 或 12"
        echo "多块盘用逗号隔开，如: 4,5,6 或 5,8,9"
        echo "输入 q 跳过RAID配置"
        echo -n "请输入: "
        
        # 正确处理read超时
        if read -t 30 disk_selection; then
            # 用户输入了内容（可能为空）
            if [ -z "$disk_selection" ]; then
                echo ""
                echo_warn "未输入选择，请重新输入"
                continue
            fi
        else
            # read超时
            echo ""
            echo_warn "输入超时，跳过RAID配置"
            disk_selection="q"
        fi
        
        # 检查是否要跳过
        if [ "$disk_selection" = "q" ] || [ "$disk_selection" = "Q" ]; then
            echo_info "跳过RAID配置"
            CHECK_STATUS["raid"]="SKIP"
            eval "$old_errexit"
            return 0
        fi
        
        # 解析选择的磁盘
        IFS=',' read -ra selected_disks <<< "$disk_selection"
        declare -a raid_devices
        local raid_device_count=0
        local input_valid=true
        
        for disk_idx in "${selected_disks[@]}"; do
            # 去除空格
            disk_idx=$(echo $disk_idx | tr -d ' ')
            
            # 验证输入是否为数字
            if ! [[ "$disk_idx" =~ ^[0-9]+$ ]]; then
                echo_error "无效的磁盘序号: $disk_idx"
                echo_warn "请输入有效的数字，多个磁盘用英文逗号分隔"
                input_valid=false
                break
            fi
            
            # 验证序号是否在范围内
            if [ "$disk_idx" -ge "$disk_count" ]; then
                echo_error "磁盘序号超出范围: $disk_idx (有效范围: 0-$((disk_count-1)))"
                input_valid=false
                break
            fi
        
            # 检查磁盘是否已经做了RAID
            if [[ "${disk_raid_status[$disk_idx]}" != "否" ]]; then
                echo_warn "磁盘 ${disk_names[$disk_idx]} 已经加入RAID (${disk_raid_status[$disk_idx]})，跳过"
                continue
            fi
            
            raid_devices[$raid_device_count]="${disk_paths[$disk_idx]}"
            ((raid_device_count++))
        done
        
        # 如果输入无效，重新开始循环
        if [ "$input_valid" = false ]; then
            continue
        fi
        
        # 检查是否有有效的磁盘
        if [ "$raid_device_count" -eq 0 ]; then
            echo_error "没有可用的磁盘创建RAID"
            echo_warn "请重新选择磁盘"
            continue
        fi
        
        # 输入有效，跳出循环
        break
    done
    
    echo ""
    echo_info "已选择 $raid_device_count 个磁盘:"
    for dev in "${raid_devices[@]}"; do
        echo "  - $dev"
    done
    
    # 选择RAID类型 - 根据磁盘数量动态显示可用选项
    echo ""
    echo -e "${YELLOW}请选择需要做哪种RAID:${NC}"
    echo "======================================================================================================"
    echo "  选项         最少磁盘数     容量利用率     冗余性         性能特点"
    echo "======================================================================================================"
    
    # 动态显示可用的RAID选项
    local option_num=1
    declare -a available_options
    declare -a option_levels
    
    # RAID 0
    if [ "$raid_device_count" -ge 2 ]; then
        echo "  ${option_num}、RAID0     2块            100%           无             最高性能，无冗余"
        available_options[$option_num]="0"
        option_levels[$option_num]="0"
        ((option_num++))
    fi
    
    # RAID 1
    if [ "$raid_device_count" -ge 2 ]; then
        echo "  ${option_num}、RAID1     2块            50%            高             镜像，高冗余"
        available_options[$option_num]="1"
        option_levels[$option_num]="1"
        ((option_num++))
    fi
    
    # RAID 5
    if [ "$raid_device_count" -ge 3 ]; then
        local raid5_capacity=$(( (raid_device_count - 1) * 100 / raid_device_count ))
        echo "  ${option_num}、RAID5     3块            ${raid5_capacity}%            中             分布式奇偶校验"
        available_options[$option_num]="5"
        option_levels[$option_num]="5"
        ((option_num++))
    fi
    
    # RAID 6
    if [ "$raid_device_count" -ge 4 ]; then
        local raid6_capacity=$(( (raid_device_count - 2) * 100 / raid_device_count ))
        echo "  ${option_num}、RAID6     4块            ${raid6_capacity}%            高             双重奇偶校验"
        available_options[$option_num]="6"
        option_levels[$option_num]="6"
        ((option_num++))
    fi
    
    # RAID 10
    if [ "$raid_device_count" -ge 4 ] && [ $((raid_device_count % 2)) -eq 0 ]; then
        echo "  ${option_num}、RAID10    4块偶数        50%            高             镜像+条带，高性能高冗余"
        available_options[$option_num]="10"
        option_levels[$option_num]="10"
        ((option_num++))
    fi
    
    echo "======================================================================================================"
    echo "  q、跳过RAID配置"
    echo ""
    
    while true; do
        echo -n "请输入选择(1-$((option_num-1))或q): "
        
        # 正确处理read超时
        if read -t 30 raid_type; then
            # 用户输入了内容（可能为空）
            if [ -z "$raid_type" ]; then
                echo ""
                echo_warn "未输入选择，请重新输入"
                continue
            fi
        else
            # read超时
            echo ""
            echo_warn "输入超时，跳过RAID配置"
            raid_type="q"
        fi
        
        # 检查是否要跳过
        if [ "$raid_type" = "q" ] || [ "$raid_type" = "Q" ]; then
            echo_info "跳过RAID配置"
            CHECK_STATUS["raid"]="SKIP"
            eval "$old_errexit"
            return 0
        fi
        
        # 验证输入是否为有效数字
        if ! [[ "$raid_type" =~ ^[0-9]+$ ]]; then
            echo_error "请输入有效的数字"
            continue
        fi
        
        # 检查选择是否在有效范围内
        if [ "$raid_type" -ge 1 ] && [ "$raid_type" -lt "$option_num" ]; then
            raid_level="${option_levels[$raid_type]}"
            
            # 根据RAID级别设置最小磁盘数
            case $raid_level in
                0) min_disks=2 ;;
                1) min_disks=2 ;;
                5) min_disks=3 ;;
                6) min_disks=4 ;;
                10) 
                    min_disks=4
                    if [ $((raid_device_count % 2)) -ne 0 ]; then
                        echo_error "RAID10需要偶数个磁盘，当前有 $raid_device_count 个"
                        continue
                    fi
                    ;;
            esac
            
            # 最终检查磁盘数量
            if [ "$raid_device_count" -lt "$min_disks" ]; then
                echo_error "RAID$raid_level 需要至少 $min_disks 个磁盘，当前只有 $raid_device_count 个"
                continue
            fi
            
            break
        else
            echo_error "无效的选择，请输入 1-$((option_num-1)) 或 q"
            continue
        fi
    done
    
    # 确认创建RAID
    echo ""
    echo "======================================================================================================"
    echo_warn "即将创建 RAID$raid_level，这将清除所选磁盘上的所有数据！"
    echo "======================================================================================================"
    
    # 添加调试信息
    echo_info "[调试] 进入确认步骤..."
    echo_info "[调试] 当前终端: $(tty 2>/dev/null || echo '未知')"
    echo_info "[调试] 标准输入状态: $(test -t 0 && echo '终端' || echo '非终端')"
    echo -e "${RED}警告: 此操作不可逆！所有数据将被清除！${NC}"
    echo ""
    echo "将要清除的磁盘:"
    for dev in "${raid_devices[@]}"; do
        echo "  - $dev"
    done
    echo ""
    
    # 使用简单的read命令，带超时
    echo -e "${YELLOW}请输入 y 确认，或 n 取消 (30秒超时):${NC}"
    
    # 直接使用read -t 超时选项
    confirm=""
    read -t 30 -r -p "> " confirm || true
    
    # 如果没有输入或超时，默认取消
    if [ -z "$confirm" ]; then
        echo ""
        echo_warn "没有输入或超时，自动取消操作"
        confirm="n"
    fi
    
    # 显示用户选择
    echo "您的选择: $confirm"
    
    if [[ "$confirm" != "y" ]] && [[ "$confirm" != "Y" ]]; then
        echo ""
        echo_info "用户取消RAID创建"
        CHECK_STATUS["raid"]="SKIP"
        eval "$old_errexit"
        return 0
    fi
    
    echo ""
    echo_info "用户确认，开始创建RAID..."
    
    # 查找可用的md设备号
    local md_num=0
    while [ -e "/dev/md$md_num" ]; do
        ((md_num++))
    done
    local md_device="/dev/md$md_num"
    
    # 清理磁盘 - 添加更详细的进度显示
    echo_info "正在准备磁盘..."
    echo "--------------------------------------------------------------------------------"
    local disk_num=1
    for dev in "${raid_devices[@]}"; do
        echo -e "${YELLOW}[$disk_num/${#raid_devices[@]}] 处理磁盘: $dev${NC}"
        
        # 显示每个步骤
        echo -n "  1. 停止现有RAID..."
        mdadm --stop "$dev" &>/dev/null 2>&1
        echo " 完成"
        
        echo -n "  2. 清除RAID超级块..."
        mdadm --zero-superblock --force "$dev" &>/dev/null 2>&1
        echo " 完成"
        
        echo -n "  3. 清除文件系统签名..."
        wipefs -a -f "$dev" &>/dev/null 2>&1
        echo " 完成"
        
        echo -n "  4. 清除分区表..."
        # 使用sgdisk清除GPT分区表
        if command -v sgdisk &>/dev/null; then
            sgdisk -Z "$dev" &>/dev/null 2>&1
        else
            dd if=/dev/zero of="$dev" bs=512 count=1 &>/dev/null 2>&1
        fi
        echo " 完成"
        
        echo -n "  5. 初始化磁盘头部..."
        dd if=/dev/zero of="$dev" bs=1M count=1 oflag=direct &>/dev/null 2>&1
        echo " 完成"
        
        # 刷新内核分区表
        partprobe "$dev" &>/dev/null 2>&1
        
        echo -e "  ${GREEN}磁盘 $dev 清理完成${NC}"
        ((disk_num++))
    done
    echo "--------------------------------------------------------------------------------"
    echo_info "所有磁盘准备完成"
    
    # 创建RAID - 增强进度显示版本
    echo ""
    echo "======================================================================================================"
    echo "                                         开始RAID创建任务                                              "
    echo "======================================================================================================"
    
    # 任务进度跟踪
    local total_steps=6
    local current_step=0
    
    # 步骤1: 设置参数
    ((current_step++))
    echo -e "${BLUE}[进度 $current_step/$total_steps] 设置RAID参数...${NC}"
    
    # 根据RAID级别设置特定参数
    local mdadm_options=""
    
    # RAID 6 需要指定算法
    if [ "$raid_level" = "6" ]; then
        mdadm_options="--layout=left-symmetric"
        echo "  - RAID6布局: left-symmetric"
    fi
    
    echo "  - RAID级别: $raid_level"
    echo "  - 磁盘数量: $raid_device_count"
    echo "  - 设备名称: $md_device"
    
    # 步骤2: 构建命令
    ((current_step++))
    echo -e "${BLUE}[进度 $current_step/$total_steps] 构建创建命令...${NC}"
    
    # 构建mdadm命令 - 使用更安全的参数
    local cmd_base="mdadm --create $md_device"
    local cmd_params="--level=$raid_level --raid-devices=$raid_device_count"
    local cmd_flags="--assume-clean --run --force"
    
    echo "  - 基本命令: $cmd_base"
    echo "  - 参数: $cmd_params"
    echo "  - 标志: $cmd_flags"
    
    # 步骤3: 执行创建
    ((current_step++))
    echo -e "${BLUE}[进度 $current_step/$total_steps] 执行创建RAID命令...${NC}"
    
    # 创建临时脚本来执行mdadm命令
    cat > /tmp/create_raid_temp.sh << 'EOF'
#!/bin/bash
echo "[开始] 创建RAID阵列..."
echo "执行命令:"
EOF
    
    # 构建完整命令并写入脚本
    echo "mdadm --create $md_device \\" >> /tmp/create_raid_temp.sh
    echo "      --level=$raid_level \\" >> /tmp/create_raid_temp.sh
    echo "      --raid-devices=$raid_device_count \\" >> /tmp/create_raid_temp.sh
    echo "      --metadata=1.2 \\" >> /tmp/create_raid_temp.sh
    echo "      --assume-clean \\" >> /tmp/create_raid_temp.sh
    echo "      --run \\" >> /tmp/create_raid_temp.sh
    echo "      --force \\" >> /tmp/create_raid_temp.sh
    if [ -n "$mdadm_options" ]; then
        echo "      $mdadm_options \\" >> /tmp/create_raid_temp.sh
    fi
    echo "      ${raid_devices[@]}" >> /tmp/create_raid_temp.sh
    echo "RESULT=\$?" >> /tmp/create_raid_temp.sh
    echo "if [ \$RESULT -eq 0 ]; then" >> /tmp/create_raid_temp.sh
    echo "    echo \"\"" >> /tmp/create_raid_temp.sh
    echo "    echo \"[成功] RAID创建命令执行成功\"" >> /tmp/create_raid_temp.sh
    echo "else" >> /tmp/create_raid_temp.sh
    echo "    echo \"\"" >> /tmp/create_raid_temp.sh
    echo "    echo \"[失败] RAID创建命令执行失败，错误码: \$RESULT\"" >> /tmp/create_raid_temp.sh
    echo "fi" >> /tmp/create_raid_temp.sh
    echo "exit \$RESULT" >> /tmp/create_raid_temp.sh
    
    chmod +x /tmp/create_raid_temp.sh
    
    # 显示将要执行的命令
    echo "  - 构建的命令:"
    echo -n "    "
    grep "^mdadm" /tmp/create_raid_temp.sh | head -1
    
    echo ""
    echo "  - 开始执行:"
    echo "--------------------------------------------------------------------------------"
    
    # 先尝试检查是否需要安装expect
    if ! command -v expect &>/dev/null; then
        echo "  - 安装expect工具..."
        yum install -y expect &>/dev/null 2>&1
    fi
    
    # 使用expect自动应答（如果可用）
    if command -v expect &>/dev/null; then
        cat > /tmp/raid_expect.exp << 'EXPECT_EOF'
#!/usr/bin/expect
set timeout 30
log_user 0
log_file -noappend /tmp/raid_create_detail.log
spawn bash /tmp/create_raid_temp.sh

# 捕获并处理输出
expect {
    -re "Continue creating array.*" {
        send "y\n"
        exp_continue
    }
    -re ".*\[y/n\].*" {
        send "y\n"
        exp_continue
    }
    -re ".*\(y/n\).*" {
        send "y\n"
        exp_continue
    }
    -re "\[.*\]" {
        # 捕获并显示有用的信息
        set output $expect_out(buffer)
        puts -nonewline "$output"
        exp_continue
    }
    -re "mdadm:.*" {
        # 显示mdadm输出
        set output $expect_out(buffer)
        puts "$output"
        exp_continue
    }
    eof {
        catch wait result
        exit [lindex $result 3]
    }
    timeout {
        puts "\n[错误] 命令执行超时（30秒）"
        exit 124
    }
}
EXPECT_EOF
        chmod +x /tmp/raid_expect.exp
        
        # 执行expect脚本，过滤输出
        echo "  - 正在创建RAID阵列..."
        echo "    等待mdadm完成..."
        
        # 静默执行，只显示关键信息
        /tmp/raid_expect.exp > /tmp/expect_output.tmp 2>&1
        create_result=$?
        
        # 提取并显示关键信息
        if [ -f /tmp/expect_output.tmp ]; then
            grep -E "(mdadm: array|started|failed|error)" /tmp/expect_output.tmp 2>/dev/null
            rm -f /tmp/expect_output.tmp
        fi
        
        # 显示关键信息
        if [ -f /tmp/raid_create_detail.log ]; then
            # 只显示重要信息
            grep -E "(mdadm:|\[开始\]|\[结束\]|array|started|failed)" /tmp/raid_create_detail.log 2>/dev/null | tail -10
        fi
    else
        # 如果没有expect，使用yes管道，过滤输出
        echo "  - 正在创建RAID阵列..."
        yes | timeout 30 bash /tmp/create_raid_temp.sh 2>&1 | grep -v "^y$" | tee /tmp/raid_create.log
        create_result=${PIPESTATUS[1]}
        
        # 检查是否超时
        if [ $create_result -eq 124 ]; then
            echo -e "\n${RED}超时！命令执行超过30秒${NC}"
        fi
    fi
    
    echo "--------------------------------------------------------------------------------"
    
    # 清理临时文件
    rm -f /tmp/create_raid_temp.sh /tmp/raid_expect.exp
    
    # 检查结果
    echo ""
    if [ $create_result -eq 124 ]; then
        echo_error "[错误] RAID创建超时（超过30秒）"
        echo_warn "请检查:"
        echo "  1. 磁盘是否正常响应"
        echo "  2. 是否有其他进程占用磁盘"
        echo "  3. 尝试重启后再试"
        create_result=1
    elif [ $create_result -eq 0 ]; then
        echo_info "[成功] RAID创建命令执行成功"
    else
        echo_error "[失败] 命令执行失败，错误码: $create_result"
        if [ -f /tmp/raid_create.log ]; then
            echo "错误信息:"
            cat /tmp/raid_create.log | tail -10
        fi
    fi
    
    if [ $create_result -eq 0 ]; then
        # 步骤4: 检查设备
        ((current_step++))
        echo -e "${BLUE}[进度 $current_step/$total_steps] 检查RAID设备状态...${NC}"
        
        # 等待RAID设备出现
        echo "  - 等待设备 $md_device 出现..."
        local wait_count=0
        while [ ! -e "$md_device" ] && [ $wait_count -lt 10 ]; do
            echo -n "    等待中($wait_count/10)..."
            sleep 1
            ((wait_count++))
        done
        echo ""
        
        if [ -e "$md_device" ]; then
            echo_info "  - RAID设备已创建: $md_device"
        else
            echo_warn "  - RAID设备未出现，但继续处理..."
        fi
        
        # 步骤5: 保存配置
        ((current_step++))
        echo -e "${BLUE}[进度 $current_step/$total_steps] 保存RAID配置...${NC}"
        
        if [ -e "$md_device" ]; then
            # 确保mdadm.conf存在
            echo "  - 检查配置文件..."
            if [ ! -f /etc/mdadm.conf ]; then
                touch /etc/mdadm.conf
                echo "    创建新配置文件"
            fi
            
            # 备份现有配置
            if [ -s /etc/mdadm.conf ]; then
                local backup_file="/etc/mdadm.conf.bak.$(date +%Y%m%d%H%M%S)"
                cp /etc/mdadm.conf $backup_file
                echo "    备份现有配置到: $backup_file"
            fi
            
            # 添加新的RAID配置
            echo "  - 保存RAID配置..."
            mdadm --detail --scan --verbose | grep "ARRAY $md_device" >> /etc/mdadm.conf 2>/dev/null
            
            # 更新initramfs以包含RAID配置
            if command -v dracut &>/dev/null; then
                echo "  - 更新initramfs..."
                dracut -f &>/dev/null 2>&1 &
                local dracut_pid=$!
                local wait_time=0
                while kill -0 $dracut_pid 2>/dev/null && [ $wait_time -lt 10 ]; do
                    echo -n "."
                    sleep 1
                    ((wait_time++))
                done
                echo ""
            fi
        else
            echo_warn "  - RAID设备未就绪，跳过配置保存"
        fi
        
        # 步骤6: 完成
        ((current_step++))
        echo -e "${BLUE}[进度 $current_step/$total_steps] RAID创建完成${NC}"
        echo_info "RAID$raid_level 创建成功!"
        
        # 显示RAID信息
        echo ""
        echo "======================================================================================================"
        echo "                                        新创建的RAID信息                                             "
        echo "======================================================================================================"
        
        if [ -e "$md_device" ]; then
            mdadm --detail $md_device 2>/dev/null | grep -E "Raid Level|Array Size|Used Dev Size|Raid Devices|Total Devices|State|Active Devices|Working Devices|Failed Devices|Spare Devices" || echo "正在获取信息..."
            
            echo ""
            echo "成员磁盘:"
            # 改进的成员磁盘显示
            local member_list=$(mdadm --detail $md_device 2>/dev/null | awk '
                /Number   Major   Minor   RaidDevice State/ { found=1; next }
                found && /^[[:space:]]*$/ { exit }
                found && /^[[:space:]]*[0-9]/ {
                    device = $NF
                    if (device ~ /^\/dev\//) {
                        print "  - " device
                    }
                }
            ')
            
            if [ -n "$member_list" ]; then
                echo "$member_list"
            else
                echo "  正在初始化..."
            fi
        else
            echo "设备正在初始化，请稍后使用 'mdadm --detail $md_device' 查看"
        fi
        
        echo "======================================================================================================"
        
        # 显示RAID同步进度
        echo ""
        echo_info "RAID同步状态:"
        if [ -f /proc/mdstat ]; then
            cat /proc/mdstat | grep -A 1 "${md_device##*/}" || echo "  正在初始化..."
        fi
        
        # 如果是RAID 1/5/6/10，设置为后台同步，避免阻塞
        if [ "$raid_level" != "0" ]; then
            echo_info "设置RAID为后台同步模式..."
            # 设置同步速度限制，避免影响系统性能
            echo 50000 > /proc/sys/dev/raid/speed_limit_min 2>/dev/null
            echo 200000 > /proc/sys/dev/raid/speed_limit_max 2>/dev/null
        fi
        
        # 创建文件系统 - 增强版本
        echo ""
        echo_info "配置文件系统..."
        echo -e "${YELLOW}选择文件系统类型:${NC}"
        echo "  1、XFS (推荐用于大文件和高性能)"
        echo "  2、EXT4 (传统Linux文件系统，兼容性好)"
        echo "  3、BTRFS (现代文件系统，支持快照)"
        echo "  4、暂不创建文件系统"
        
        # 使用超时读取，避免永久等待
        echo ""
        echo -e "${YELLOW}请选择 (1-4) [默认: 1]:${NC}"
        fs_choice=""
        read -t 10 -r -p "> " fs_choice || true
        
        # 如果没有输入或超时，默认选择XFS
        if [ -z "$fs_choice" ]; then
            echo "使用默认选项: XFS"
            fs_choice="1"
        fi
        
        echo "您的选择: $fs_choice"
        
        local fs_type=""
        case $fs_choice in
            1)
                echo_info "正在创建XFS文件系统..."
                if mkfs.xfs -f $md_device &>/dev/null 2>&1; then
                    echo_info "XFS文件系统创建成功"
                    fs_type="xfs"
                else
                    echo_error "XFS文件系统创建失败"
                fi
                ;;
            2)
                echo_info "正在创建EXT4文件系统..."
                if mkfs.ext4 -F $md_device &>/dev/null 2>&1; then
                    echo_info "EXT4文件系统创建成功"
                    fs_type="ext4"
                else
                    echo_error "EXT4文件系统创建失败"
                fi
                ;;
            3)
                echo_info "正在创建BTRFS文件系统..."
                if mkfs.btrfs -f $md_device &>/dev/null 2>&1; then
                    echo_info "BTRFS文件系统创建成功"
                    fs_type="btrfs"
                else
                    echo_error "BTRFS文件系统创建失败"
                fi
                ;;
            4)
                echo_info "跳过文件系统创建"
                ;;
            *)
                echo_info "无效选择，跳过文件系统创建"
                ;;
        esac
        
        # 如果文件系统创建成功，询问是否挂载
        if [ -n "$fs_type" ]; then
                
                # 使用循环处理挂载点输入
                local mount_completed=false
                while [ "$mount_completed" = false ]; do
                    # 询问挂载点
                    echo ""
                    echo -e "${YELLOW}请输入挂载点路径（如 /data），留空则不挂载（30秒超时）:${NC}"
                    mount_point=""
                    read -t 30 -r -p "> " mount_point || true
                    
                    # 如果超时或空输入，跳过挂载
                    if [ -z "$mount_point" ]; then
                        echo_info "跳过挂载步骤"
                        mount_completed=true
                        break
                    fi
                    
                    echo "挂载点: $mount_point"
                    
                    # 检查挂载点是否存在
                    if [ ! -d "$mount_point" ]; then
                        echo_warn "目录 $mount_point 不存在"
                        echo -e "${YELLOW}是否创建该目录? (y/n/q-退出挂载):${NC}"
                        local create_dir=""
                        read -t 10 -r -p "> " create_dir || true
                        
                        case "$create_dir" in
                            y|Y)
                                echo_info "创建目录 $mount_point"
                                if mkdir -p "$mount_point"; then
                                    echo_info "目录创建成功"
                                else
                                    echo_error "目录创建失败，请重新输入"
                                    continue
                                fi
                                ;;
                            q|Q)
                                echo_info "退出挂载配置"
                                mount_completed=true
                                break
                                ;;
                            n|N|*)
                                echo_info "不创建目录，请重新输入挂载点"
                                continue
                                ;;
                        esac
                    else
                        # 目录已存在，检查是否为空
                        if [ "$(ls -A "$mount_point" 2>/dev/null)" ]; then
                            echo_warn "警告: 目录 $mount_point 不为空"
                            echo -e "${YELLOW}确定要挂载到非空目录吗? (y/n):${NC}"
                            local confirm_mount=""
                            read -t 10 -r -p "> " confirm_mount || true
                            
                            if [[ "$confirm_mount" != "y" ]] && [[ "$confirm_mount" != "Y" ]]; then
                                echo_info "取消挂载到该目录，请重新输入"
                                continue
                            fi
                        fi
                    fi
                    
                    # 执行挂载
                    if mount $md_device "$mount_point"; then
                        echo_info "RAID已挂载到 $mount_point"
                        mount_completed=true
                        
                        # 获取文件系统的UUID
                        local fs_uuid=$(blkid -o value -s UUID $md_device)
                        
                        if [ -n "$fs_uuid" ]; then
                            echo_info "文件系统UUID: $fs_uuid"
                            
                            # 备份现有的fstab
                            cp /etc/fstab /etc/fstab.bak.$(date +%Y%m%d%H%M%S)
                            echo_info "已备份 /etc/fstab"
                            
                            # 使用UUID添加到fstab
                            echo "# RAID mount added by qfusion.sh on $(date)" >> /etc/fstab
                            echo "UUID=$fs_uuid $mount_point $fs_type defaults,nofail,x-systemd.device-timeout=10 0 0" >> /etc/fstab
                            echo_info "已使用UUID添加到 /etc/fstab"
                            
                            # 先卸载当前挂载
                            umount $mount_point 2>/dev/null
                            
                            # 使用mount -a测试fstab配置
                            echo_info "测试fstab配置..."
                            if mount -a 2>/tmp/mount_error.log; then
                                echo_info "fstab配置正确，挂载成功"
                                
                                # 验证挂载
                                if mountpoint -q "$mount_point"; then
                                    echo_info "验证: $mount_point 已正确挂载"
                                    
                                    # 显示挂载信息
                                    echo ""
                                    echo "挂载详情:"
                                    df -h $mount_point | tail -1 | awk '{print "  设备: " $1}'
                                    df -h $mount_point | tail -1 | awk '{print "  容量: " $2}'
                                    df -h $mount_point | tail -1 | awk '{print "  已用: " $3}'
                                    df -h $mount_point | tail -1 | awk '{print "  可用: " $4}'
                                    df -h $mount_point | tail -1 | awk '{print "  使用率: " $5}'
                                    echo "  文件系统: $fs_type"
                                    echo "  挂载选项: defaults,nofail,x-systemd.device-timeout=10"
                                else
                                    echo_error "挂载验证失败"
                                fi
                            else
                                echo_error "fstab配置测试失败:"
                                cat /tmp/mount_error.log
                                
                                # 恢复原fstab
                                echo_warn "恢复原始fstab配置..."
                                local backup_file=$(ls -t /etc/fstab.bak.* 2>/dev/null | head -1)
                                if [ -n "$backup_file" ]; then
                                    mv "$backup_file" /etc/fstab
                                fi
                                
                                # 直接挂载
                                echo_info "尝试直接挂载..."
                                if mount $md_device "$mount_point"; then
                                    echo_info "直接挂载成功（但未添加到fstab）"
                                else
                                    echo_error "挂载失败"
                                fi
                            fi
                            
                            # 清理临时文件
                            rm -f /tmp/mount_error.log
                        else
                            echo_warn "无法获取UUID，使用设备名挂载"
                            
                            # 使用设备名添加到fstab（作为备用方案）
                            echo "$md_device $mount_point $fs_type defaults,nofail 0 0" >> /etc/fstab
                            echo_info "已添加到 /etc/fstab（使用设备名）"
                            
                            # 显示挂载信息
                            df -h $mount_point
                        fi
                    else
                        echo_error "挂载失败，请检查挂载点或重新输入"
                        continue
                    fi
                done  # while循环结束
        fi
        
        # 设置RAID性能优化参数
        echo ""
        echo_info "应用RAID性能优化..."
        
        # 设置条带缓存大小（适用于RAID 5/6）
        if [ "$raid_level" = "5" ] || [ "$raid_level" = "6" ]; then
            echo 8192 > /sys/block/${md_device##*/}/md/stripe_cache_size 2>/dev/null
        fi
        
        # 设置预读缓存
        blockdev --setra 65536 $md_device 2>/dev/null
        
        # 显示最终状态
        echo ""
        echo_info "RAID配置完成！"
        echo "RAID设备: $md_device"
        echo "RAID级别: RAID$raid_level"
        echo "成员磁盘: ${raid_device_count}个"
        
        # 显示监控命令
        echo ""
        echo -e "${GREEN}使用以下命令监控RAID状态:${NC}"
        echo "  mdadm --detail $md_device    # 查看RAID详细信息"
        echo "  cat /proc/mdstat              # 查看RAID状态和同步进度"
        echo "  mdadm --monitor $md_device   # 实时监控RAID状态"
        
        CHECK_STATUS["raid"]="CONFIGURED"
        eval "$old_errexit"
    else
        echo ""
        echo_error "[错误] RAID创建失败"
        echo_warn "错误信息:"
        if [ -n "$create_output" ]; then
            echo "$create_output" | head -20
        else
            echo "无输出信息"
        fi
        
        # 尝试清理失败的RAID
        mdadm --stop $md_device &>/dev/null 2>&1
        for dev in "${raid_devices[@]}"; do
            mdadm --zero-superblock "$dev" &>/dev/null 2>&1
        done
        
        CHECK_STATUS["raid"]="FAIL"
        eval "$old_errexit"
        return 1
    fi
    
    # 恢复错误处理设置
    eval "$old_errexit"
}

# 显示最终汇总
show_summary() {
    echo ""
    show_separator
    echo "           检查汇总"
    show_separator
    
    # 简化处理，避免在set -e模式下的问题
    echo_info "所有检查项已完成"
    
    # 始终返回0
    return 0
    
    # 下面的代码在远程模式下不会执行，因为数组未传递
    local pass_count=0
    local fixed_count=0
    local fail_count=0
    local warn_count=0
    
    for key in "${!CHECK_STATUS[@]}"; do
        case "${CHECK_STATUS[$key]}" in
            "PASS") ((pass_count++)) ;;
            "FIXED") ((fixed_count++)) ;;
            "FAIL") ((fail_count++)) ;;
            "WARN") ((warn_count++)) ;;
        esac
    done
    
    echo -e "${GREEN}通过:${NC} $pass_count 项"
    echo -e "${BLUE}已修复:${NC} $fixed_count 项"
    echo -e "${YELLOW}警告:${NC} $warn_count 项"
    echo -e "${RED}未修复:${NC} $fail_count 项"
    
    if [ $fail_count -eq 0 ] && [ $warn_count -eq 0 ]; then
        echo ""
        echo_info "所有检查项已通过或修复！"
    elif [ $warn_count -gt 0 ] && [ $fail_count -eq 0 ]; then
        echo ""
        echo_warn "存在警告项，请根据实际情况处理"
    else
        echo ""
        echo_error "仍有未修复的问题，请手动处理"
    fi
    
    # 如果有需要重启的项目
    if [[ "${CHECK_STATUS[limits]}" == "FIXED" ]] || [[ "${CHECK_STATUS[selinux]}" == "FIXED" ]]; then
        echo ""
        echo_warn "提示: 部分修改需要重启系统后生效"
    fi
    
    # 始终返回0
    return 0
}

# 执行所有检查（单节点）
run_all_checks() {
    echo ""
    echo_info "开始执行所有检查项..."
    echo ""
    
    # 先检查YUM源
    check_and_fix_yum_source
    echo ""
    
    check_and_fix_hardware_time
    echo ""
    
    check_and_fix_network_speed
    echo ""
    
    check_and_fix_dns
    echo ""
    
    check_and_fix_network_service
    echo ""
    
    check_and_fix_swap
    echo ""
    
    check_and_fix_selinux
    echo ""
    
    check_and_fix_io_scheduler
    echo ""
    
    check_and_fix_auditd
    echo ""
    
    check_and_fix_hostname
    echo ""
    
    check_and_fix_packages
    echo ""
    
    check_and_fix_containers
    echo ""
    
    check_and_fix_tmp
    echo ""
    
    check_and_fix_kubernetes
    echo ""
    
    check_and_fix_virbr0
    echo ""
    
    check_cpu_avx
    echo ""
    
    check_and_fix_limits
    echo ""
    
    check_and_fix_nproc_config
    echo ""
    
    check_and_configure_raid
    
    # 显示汇总
    show_summary
    
    # 始终返回0表示成功完成
    return 0
}

# ================== 批量管理相关函数 ==================

# 创建检查脚本（用于远程执行）
create_check_script() {
    cat > "$CHECK_SCRIPT" << 'SCRIPT_END'
#!/bin/bash

# 非交互式检查脚本，只检查不修改

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ISSUES=0

# 检查各项配置
check_all() {
    # 1. 硬件时间
    sys_time=$(date '+%s')
    hw_time_str=$(hwclock -r 2>/dev/null || echo "ERROR")
    if [ "$hw_time_str" != "ERROR" ]; then
        hw_time=$(date -d "$hw_time_str" '+%s' 2>/dev/null || echo "0")
        time_diff=$((sys_time - hw_time))
        [ $time_diff -lt 0 ] && time_diff=$((-time_diff))
        
        if [ $time_diff -le 2 ]; then
            echo -e "${GREEN}✓${NC} 硬件时间: 同步"
        else
            echo -e "${RED}✗${NC} 硬件时间: 差异${time_diff}秒"
            ((ISSUES++))
        fi
    else
        echo -e "${RED}✗${NC} 硬件时间: 无法读取"
        ((ISSUES++))
    fi
    
    # 2. Swap
    swap_total=$(free -m | grep Swap | awk '{print $2}')
    if [ "$swap_total" -eq 0 ]; then
        echo -e "${GREEN}✓${NC} Swap: 已关闭"
    else
        echo -e "${RED}✗${NC} Swap: ${swap_total}MB"
        ((ISSUES++))
    fi
    
    # 3. SELinux
    if [ -f /etc/selinux/config ]; then
        selinux_status=$(getenforce 2>/dev/null || echo "Disabled")
        if [ "$selinux_status" = "Disabled" ]; then
            echo -e "${GREEN}✓${NC} SELinux: 已禁用"
        else
            echo -e "${RED}✗${NC} SELinux: $selinux_status"
            ((ISSUES++))
        fi
    fi
    
    # 4. 主机名
    hostname=$(hostname)
    if [[ "$hostname" =~ [A-Z] ]] || [[ "$hostname" =~ [^a-z0-9\-\.] ]]; then
        echo -e "${RED}✗${NC} 主机名: $hostname (格式错误)"
        ((ISSUES++))
    else
        echo -e "${GREEN}✓${NC} 主机名: $hostname"
    fi
    
    # 5. 容器软件
    containers=$(rpm -qa 2>/dev/null | grep -E "docker|podman" | wc -l)
    if [ $containers -eq 0 ]; then
        echo -e "${GREEN}✓${NC} 容器软件: 未安装"
    else
        echo -e "${RED}✗${NC} 容器软件: ${containers}个包"
        ((ISSUES++))
    fi
    
    # 6. /tmp权限
    perms=$(stat -c %a /tmp)
    if [ "$perms" = "777" ] || [ "$perms" = "1777" ]; then
        echo -e "${GREEN}✓${NC} /tmp权限: $perms"
    else
        echo -e "${RED}✗${NC} /tmp权限: $perms"
        ((ISSUES++))
    fi
    
    echo "ISSUES_COUNT=$ISSUES"
}

check_all
SCRIPT_END
    
    chmod +x "$CHECK_SCRIPT"
}

# 检查单个节点（批量模式）
check_remote_node() {
    local ip=$1
    local hostname=$2
    local user=$3
    local auth=$4
    
    echo_blue "[$hostname] 执行检查..."
    
    # 构建SSH/SCP命令
    # 先尝试使用SSH密钥
    if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no $user@$ip "echo ok" &>/dev/null 2>&1; then
        # SSH密钥认证成功
        ssh_cmd="ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no $user@$ip"
        scp_cmd="scp -o StrictHostKeyChecking=no"
    elif [[ "$auth" == /* ]]; then
        # 使用指定的密钥文件
        ssh_cmd="ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i $auth $user@$ip"
        scp_cmd="scp -o StrictHostKeyChecking=no -i $auth"
    else
        # 使用密码认证
        if command -v sshpass &>/dev/null; then
            ssh_cmd="sshpass -p $auth ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no $user@$ip"
            scp_cmd="sshpass -p $auth scp -o StrictHostKeyChecking=no"
        elif [ -f /root/ssh_connect.exp ] && [ -f /root/scp_file.exp ]; then
            # 使用expect脚本作为备选方案
            echo_info "[$hostname] 使用expect进行SSH连接"
            ssh_cmd="/root/ssh_connect.exp $ip $user '$auth'"
            scp_cmd="use_expect_scp"  # 标记使用expect传输
        else
            echo_error "[$hostname] 需要sshpass或使用SSH密钥"
            echo_info "尝试使用expect创建连接脚本..."
            create_expect_scripts
            if [ -f /root/ssh_connect.exp ] && [ -f /root/scp_file.exp ]; then
                ssh_cmd="/root/ssh_connect.exp $ip $user '$auth'"
                scp_cmd="use_expect_scp"
            else
                return 1
            fi
        fi
    fi
    
    # 复制检查脚本
    if [ "$scp_cmd" = "use_expect_scp" ]; then
        # 确保检查脚本存在
        if [ ! -f "$CHECK_SCRIPT" ]; then
            echo_error "[$hostname] 检查脚本不存在: $CHECK_SCRIPT"
            return 1
        fi
        # 使用expect进行SCP传输
        /root/scp_file.exp "$CHECK_SCRIPT" "$user" "$ip" "/tmp/$(basename $CHECK_SCRIPT)" "$auth" 2>/dev/null
        if [ $? -ne 0 ]; then
            echo_error "[$hostname] 无法传输检查脚本到远程节点"
            return 1
        fi
    else
        $scp_cmd "$CHECK_SCRIPT" "$user@$ip:/tmp/" &>/dev/null
    fi
    
    # 执行检查
    local result
    if [[ "$ssh_cmd" == *ssh_connect.exp* ]]; then
        # 使用expect脚本执行远程命令
        result=$(/root/ssh_connect.exp "$ip" "$user" "$auth" "bash /tmp/$(basename $CHECK_SCRIPT)" 2>/dev/null)
    else
        result=$($ssh_cmd "bash /tmp/$(basename $CHECK_SCRIPT)" 2>/dev/null)
    fi
    
    if [ $? -eq 0 ]; then
        # 保存结果
        echo "$result" > "$RESULTS_DIR/${hostname}_check.log"
        
        # 提取问题数
        local issues=$(echo "$result" | grep "ISSUES_COUNT=" | cut -d= -f2)
        
        echo "$result" | grep -v "ISSUES_COUNT="
        
        if [ -z "$issues" ] || [ "$issues" = "0" ]; then
            echo_info "[$hostname] 所有检查项通过"
            return 0
        else
            echo_warn "[$hostname] 发现 $issues 个问题"
            return 1
        fi
    else
        echo_error "[$hostname] 无法连接"
        return 1
    fi
}

# 远程执行初始化脚本
remote_init_node() {
    local ip=$1
    local hostname=$2
    local user=$3
    local auth=$4
    
    echo_blue "[$hostname] 连接到节点进行初始化..."
    
    # 构建SSH命令
    # 先尝试使用SSH密钥
    if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no $user@$ip "echo ok" &>/dev/null 2>&1; then
        # SSH密钥认证成功
        ssh_cmd="ssh -t -o StrictHostKeyChecking=no $user@$ip"
        scp_cmd="scp -o StrictHostKeyChecking=no"
    elif [[ "$auth" == /* ]]; then
        # 使用指定的密钥文件
        ssh_cmd="ssh -t -o StrictHostKeyChecking=no -i $auth $user@$ip"
        scp_cmd="scp -o StrictHostKeyChecking=no -i $auth"
    else
        # 使用密码认证
        if command -v sshpass &>/dev/null; then
            ssh_cmd="sshpass -p $auth ssh -t -o StrictHostKeyChecking=no $user@$ip"
            scp_cmd="sshpass -p $auth scp -o StrictHostKeyChecking=no"
        elif [ -f /root/ssh_connect.exp ] && [ -f /root/scp_file.exp ]; then
            # 使用expect脚本作为备选方案
            echo_info "[$hostname] 使用expect进行SSH连接"
            # 注意：交互式初始化需要特殊处理
            ssh_cmd="/root/ssh_connect.exp $ip $user '$auth'"
            scp_cmd="use_expect_scp"
        else
            echo_error "[$hostname] 需要sshpass或使用SSH密钥"
            echo_info "尝试使用expect创建连接脚本..."
            create_expect_scripts
            if [ -f /root/ssh_connect.exp ] && [ -f /root/scp_file.exp ]; then
                ssh_cmd="/root/ssh_connect.exp $ip $user '$auth'"
                scp_cmd="use_expect_scp"
            else
                return 1
            fi
        fi
    fi
    
    # 将本脚本复制到远程节点
    echo_info "[$hostname] 复制初始化脚本..."
    if [ "$scp_cmd" = "use_expect_scp" ]; then
        # 使用expect进行SCP传输
        /root/scp_file.exp "$0" "$user" "$ip" "/tmp/qfusion_remote.sh" "$auth" 2>/dev/null
        # 如果是自动模式，也复制跳过RAID的脚本
        if [ "$AUTO_CONFIRM" = "1" ] && [ -f /root/remote_init_skip_raid.sh ]; then
            /root/scp_file.exp "/root/remote_init_skip_raid.sh" "$user" "$ip" "/tmp/remote_init_skip_raid.sh" "$auth" 2>/dev/null
        fi
    else
        $scp_cmd "$0" "$user@$ip:/tmp/qfusion_remote.sh" &>/dev/null
        # 如果是自动模式，也复制跳过RAID的脚本
        if [ "$AUTO_CONFIRM" = "1" ] && [ -f /root/remote_init_skip_raid.sh ]; then
            $scp_cmd "/root/remote_init_skip_raid.sh" "$user@$ip:/tmp/remote_init_skip_raid.sh" &>/dev/null
        fi
    fi
    
    if [ $? -ne 0 ]; then
        echo_error "[$hostname] 无法复制脚本"
        return 1
    fi
    
    # 在远程节点执行初始化
    echo_info "[$hostname] 执行初始化..."
    echo ""
    
    # 使用SSH连接执行远程初始化
    if [[ "$ssh_cmd" == *ssh_connect.exp* ]]; then
        # 判断是否在批量处理模式
        if [ "$AUTO_CONFIRM" = "1" ]; then
            # 批量模式：所有节点使用统一的智能脚本
            echo_info "[$hostname] 自动初始化模式（跳过RAID配置）..."
            
            # 使用统一的智能初始化脚本
            if [ -f /root/ssh_smart_init.exp ]; then
                echo_info "使用智能初始化脚本..."
                /root/ssh_smart_init.exp "$ip" "$user" "$auth" "yes"  # yes=跳过RAID
            elif [ -f /root/remote_init_wrapper.sh ]; then
                # 先复制包装脚本
                /root/scp_file.exp "/root/remote_init_wrapper.sh" "$user" "$ip" "/tmp/remote_init_wrapper.sh" "$auth" 2>/dev/null
                # 执行包装脚本
                /root/ssh_connect.exp "$ip" "$user" "$auth" "bash /tmp/remote_init_wrapper.sh yes"
            else
                # 回退到原方式
                /root/ssh_connect.exp "$ip" "$user" "$auth" "bash /tmp/remote_init_skip_raid.sh"
            fi
        else
            # 交互模式：支持RAID配置
            echo_info "[$hostname] 交互式初始化模式..."
            
            # 所有节点使用相同的处理方式
            if [ -f /root/ssh_remote_init.exp ]; then
                echo_info "[$hostname] 开始远程初始化..."
                echo_warn "请按照提示完成配置（包括RAID配置）"
                echo_info "完成后选择0退出或按 Ctrl+D 返回"
                echo ""
                /root/ssh_remote_init.exp "$ip" "$user" "$auth"
            elif [ -f /root/ssh_interactive.exp ]; then
                echo_info "[$hostname] 开始交互式初始化..."
                /root/ssh_interactive.exp "$ip" "$user" "$auth"
            else
                # 使用长时间运行的expect脚本执行远程命令
                echo_warn "[$hostname] 使用非交互模式"
                if [ -f /root/ssh_long_run.exp ]; then
                    /root/ssh_long_run.exp "$ip" "$user" "$auth" "bash /tmp/qfusion_remote.sh --remote-init"
                else
                    /root/ssh_connect.exp "$ip" "$user" "$auth" "bash /tmp/qfusion_remote.sh --remote-init"
                fi
            fi
        fi
    else
        # 使用常规SSH或sshpass执行
        if [ "$AUTO_CONFIRM" = "1" ]; then
            # 批量模式下自动退出
            $ssh_cmd "bash /tmp/qfusion_remote.sh --remote-init; exit"
        else
            $ssh_cmd "bash /tmp/qfusion_remote.sh --remote-init"
        fi
    fi
    
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        echo_info "[$hostname] 初始化完成"
        return 0
    else
        echo_error "[$hostname] 初始化失败或被中断"
        return 1
    fi
}

# 批量检查和初始化
batch_check_and_init() {
    echo ""
    show_separator
    echo "       批量检查和初始化"
    show_separator
    echo ""
    
    # 创建结果目录
    RESULTS_DIR="qfusion_batch_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$RESULTS_DIR"
    
    # 读取所有节点
    local nodes_array=()
    while IFS= read -r line; do
        [[ "$line" =~ ^# ]] || [[ -z "$line" ]] && continue
        nodes_array+=("$line")
    done < "$NODES_FILE"
    
    local total=${#nodes_array[@]}
    
    if [ $total -eq 0 ]; then
        echo_error "节点清单为空"
        return 1
    fi
    
    echo_info "发现 $total 个节点"
    echo ""
    
    # 显示节点列表
    echo "节点列表:"
    local idx=1
    for node_line in "${nodes_array[@]}"; do
        ip=$(echo "$node_line" | awk '{print $1}')
        hostname=$(echo "$node_line" | awk '{print $2}')
        role=$(echo "$node_line" | awk '{print $3}')
        echo "  $idx. $hostname ($ip) - $role"
        ((idx++))
    done
    
    echo ""
    echo "请选择操作模式:"
    echo "1. 逐个节点交互式处理（推荐）"
    echo "2. 批量快速检查（只看状态）"
    echo "3. 批量自动处理所有节点（无需确认）"
    echo "4. 返回"
    echo ""
    read -p "请选择 [1-4]: " mode
    
    case $mode in
        1)
            # 逐个节点交互式处理
            echo ""
            echo_info "开始逐个节点交互式处理..."
            echo_warn "提示: 每个节点都会进入交互式界面，您可以选择每项是否修复"
            echo ""
            
            # 暂时禁用set -e
            set +e
            
            local success_count=0
            local fail_count=0
            
            for node_line in "${nodes_array[@]}"; do
                ip=$(echo "$node_line" | awk '{print $1}')
                hostname=$(echo "$node_line" | awk '{print $2}')
                user=$(echo "$node_line" | awk '{print $4}')
                auth=$(echo "$node_line" | awk '{print $5}')
                
                echo ""
                show_separator
                echo "处理节点: $hostname ($ip)"
                show_separator
                
                # 在自动确认模式下自动处理所有节点
                if [ "$AUTO_CONFIRM" = "1" ]; then
                    echo "是否处理此节点? [Y/n/q(退出)]: [自动确认: Y]"
                    answer="y"
                else
                    read -p "是否处理此节点? [Y/n/q(退出)]: " answer
                fi
                
                if [[ "$answer" == "q" ]] || [[ "$answer" == "Q" ]]; then
                    echo_info "用户退出"
                    break
                elif [[ "$answer" == "n" ]] || [[ "$answer" == "N" ]]; then
                    echo_info "跳过节点: $hostname"
                    continue
                fi
                
                if remote_init_node "$ip" "$hostname" "$user" "$auth"; then
                    ((success_count++))
                    echo "$hostname: SUCCESS" >> "$RESULTS_DIR/summary.txt"
                else
                    ((fail_count++))
                    echo "$hostname: FAILED" >> "$RESULTS_DIR/summary.txt"
                fi
                
                echo ""
                if [ $((success_count + fail_count)) -lt $total ]; then
                    if [ "$AUTO_CONFIRM" != "1" ]; then
                        read -p "按回车键继续下一个节点..."
                    fi
                fi
            done
            
            # 恢复set -e
            set -e
            
            # 显示汇总
            echo ""
            show_separator
            echo "        处理结果汇总"
            show_separator
            echo "总节点数: $total"
            echo -e "${GREEN}成功:${NC} $success_count"
            echo -e "${RED}失败:${NC} $fail_count"
            echo -e "${YELLOW}跳过:${NC} $((total - success_count - fail_count))"
            echo ""
            echo_info "结果保存在: $RESULTS_DIR/"
            ;;
            
        2)
            # 批量快速检查
            echo ""
            echo_info "执行批量快速检查..."
            
            # 创建检查脚本
            create_check_script
            
            local passed=0
            local failed=0
            
            for node_line in "${nodes_array[@]}"; do
                ip=$(echo "$node_line" | awk '{print $1}')
                hostname=$(echo "$node_line" | awk '{print $2}')
                user=$(echo "$node_line" | awk '{print $4}')
                auth=$(echo "$node_line" | awk '{print $5}')
                
                echo ""
                echo "检查节点: $hostname ($ip)"
                echo "----------------------------------------"
                
                if check_remote_node "$ip" "$hostname" "$user" "$auth"; then
                    ((passed++))
                else
                    ((failed++))
                fi
            done
            
            # 显示汇总
            echo ""
            show_separator
            echo "        检查结果汇总"
            show_separator
            echo "总节点数: $total"
            echo -e "${GREEN}通过:${NC} $passed"
            echo -e "${RED}需要修复:${NC} $failed"
            echo ""
            
            if [ $failed -gt 0 ]; then
                echo ""
                read -p "是否对需要修复的节点进行初始化? [Y/n]: " answer
                if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                    # 重新进入交互式处理模式
                    batch_check_and_init
                fi
            else
                echo_info "所有节点检查通过！"
            fi
            ;;
            
        3)
            # 批量自动处理所有节点
            echo ""
            echo_info "开始批量自动处理所有节点..."
            echo_warn "将自动对所有节点执行检查和修复"
            echo ""
            
            # 设置自动确认模式
            export AUTO_CONFIRM=1
            
            # 暂时禁用set -e以避免单个节点失败导致整个脚本退出
            set +e
            
            local success_count=0
            local fail_count=0
            
            for node_line in "${nodes_array[@]}"; do
                ip=$(echo "$node_line" | awk '{print $1}')
                hostname=$(echo "$node_line" | awk '{print $2}')
                user=$(echo "$node_line" | awk '{print $4}')
                auth=$(echo "$node_line" | awk '{print $5}')
                
                echo ""
                show_separator
                echo "处理节点: $hostname ($ip)"
                show_separator
                
                # 使用 || true 避免set -e导致退出
                remote_init_node "$ip" "$hostname" "$user" "$auth"
                local result=$?
                
                if [ $result -eq 0 ]; then
                    ((success_count++))
                    echo "$hostname: SUCCESS" >> "$RESULTS_DIR/summary.txt"
                    echo_info "[$hostname] 处理成功"
                else
                    ((fail_count++))
                    echo "$hostname: FAILED" >> "$RESULTS_DIR/summary.txt"
                    echo_error "[$hostname] 处理失败"
                fi
            done
            
            # 显示汇总
            echo ""
            show_separator
            echo "        批量处理结果汇总"
            show_separator
            echo "总节点数: $total"
            echo -e "${GREEN}成功:${NC} $success_count 个"
            echo -e "${RED}失败:${NC} $fail_count 个"
            
            if [ $fail_count -eq 0 ]; then
                echo ""
                echo_info "所有节点处理成功！"
            else
                echo ""
                echo_warn "部分节点处理失败，请检查日志"
            fi
            
            # 恢复set -e
            set -e
            
            # 取消自动确认模式
            unset AUTO_CONFIRM
            ;;
            
        4)
            return
            ;;
            
        *)
            echo_error "无效选择"
            ;;
    esac
}

# 配置节点清单
configure_nodes() {
    echo ""
    show_separator
    echo "        配置节点清单"
    show_separator
    echo ""
    
    # 显示当前节点清单
    if [ -f "$NODES_FILE" ]; then
        local current_nodes=$(grep -v "^#" "$NODES_FILE" | grep -v "^$" | wc -l)
        if [ $current_nodes -gt 0 ]; then
            echo "当前节点清单 ($current_nodes 个节点):"
            echo "----------------------------------------"
            local idx=1
            while IFS= read -r line; do
                [[ "$line" =~ ^# ]] || [[ -z "$line" ]] && continue
                ip=$(echo "$line" | awk '{print $1}')
                hostname=$(echo "$line" | awk '{print $2}')
                role=$(echo "$line" | awk '{print $3}')
                user=$(echo "$line" | awk '{print $4}')
                auth=$(echo "$line" | awk '{print $5}')
                
                # 判断认证方式
                if [[ "$auth" == /* ]]; then
                    auth_type="密钥"
                else
                    auth_type="密码"
                fi
                
                printf "  %2d. %-15s %-15s %-8s %-8s %s\n" $idx "$hostname" "$ip" "$role" "$user" "$auth_type"
                ((idx++))
            done < "$NODES_FILE"
            echo "----------------------------------------"
            echo ""
        fi
    fi
    
    echo "请选择操作:"
    echo "1. 添加新节点"
    echo "2. 批量导入节点"
    echo "3. 从文件导入"
    echo "4. 清空并重新配置"
    echo "5. 编辑现有节点"
    echo "6. 删除节点"
    echo "7. 查看详细配置"
    echo "0. 返回"
    echo ""
    read -p "请选择 [0-7]: " choice
    
    case $choice in
        1)
            # 添加新节点
            add_single_node
            configure_nodes  # 递归显示菜单
            ;;
        2)
            # 批量导入
            batch_import_nodes
            configure_nodes
            ;;
        3)
            # 从文件导入
            import_from_file
            configure_nodes
            ;;
        4)
            # 清空重配
            echo ""
            echo_warn "此操作将清空现有配置！"
            read -p "确定要清空并重新配置吗? [y/N]: " answer
            if [[ "$answer" == "y" ]] || [[ "$answer" == "Y" ]]; then
                [ -f "$NODES_FILE" ] && mv "$NODES_FILE" "${NODES_FILE}.bak.$(date +%Y%m%d_%H%M%S)"
                create_empty_nodes_file
                batch_import_nodes
            fi
            configure_nodes
            ;;
        5)
            # 编辑现有节点
            edit_existing_node
            configure_nodes
            ;;
        6)
            # 删除节点
            delete_node
            configure_nodes
            ;;
        7)
            # 查看详细配置
            if [ -f "$NODES_FILE" ]; then
                echo ""
                echo "节点清单详细内容:"
                echo "----------------------------------------"
                cat "$NODES_FILE"
                echo "----------------------------------------"
                read -p "按回车键继续..."
            else
                echo_warn "节点清单不存在"
            fi
            configure_nodes
            ;;
        0)
            return
            ;;
        *)
            echo_error "无效选择"
            configure_nodes
            ;;
    esac
}

# 创建空的节点清单文件
create_empty_nodes_file() {
    cat > "$NODES_FILE" << EOF
# QFusion节点清单
# 格式: IP地址 主机名 角色 用户名 密码/密钥路径
# 生成时间: $(date '+%Y-%m-%d %H:%M:%S')
# 
# 示例:
# 192.168.1.10 master01 master root password123
# 192.168.1.11 master02 master root /root/.ssh/id_rsa

EOF
}

# 添加单个节点
add_single_node() {
    echo ""
    echo_info "添加新节点"
    echo ""
    
    # 输入IP地址
    while true; do
        read -p "IP地址: " ip
        if [[ "$ip" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
            break
        else
            echo_error "IP地址格式不正确"
        fi
    done
    
    # 输入主机名
    while true; do
        read -p "主机名: " hostname
        if [[ "$hostname" =~ ^[a-z0-9]([a-z0-9\-]*[a-z0-9])?$ ]]; then
            break
        else
            echo_error "主机名只能包含小写字母、数字和连字符"
        fi
    done
    
    # 选择角色
    echo "节点角色:"
    echo "1. master (主节点)"
    echo "2. worker (工作节点)"
    echo "3. 自定义"
    read -p "请选择 [1-3]: " role_choice
    case $role_choice in
        1) role="master" ;;
        2) role="worker" ;;
        3) read -p "输入角色名: " role ;;
        *) role="worker" ;;
    esac
    
    # 输入用户名
    read -p "用户名 [默认: root]: " user
    [ -z "$user" ] && user="root"
    
    # 选择认证方式
    echo "认证方式:"
    echo "1. 密码认证"
    echo "2. SSH密钥认证"
    read -p "请选择 [1-2]: " auth_choice
    
    if [ "$auth_choice" = "2" ]; then
        # SSH密钥认证
        read -p "密钥文件路径 [默认: /root/.ssh/id_rsa]: " auth
        [ -z "$auth" ] && auth="/root/.ssh/id_rsa"
        
        if [ ! -f "$auth" ]; then
            echo_warn "密钥文件不存在: $auth"
            read -p "是否继续? [Y/n]: " answer
            if [[ "$answer" == "n" ]] || [[ "$answer" == "N" ]]; then
                return
            fi
        fi
    else
        # 密码认证
        while true; do
            read -s -p "密码: " auth
            echo
            read -s -p "确认密码: " auth_confirm
            echo
            if [ "$auth" = "$auth_confirm" ]; then
                break
            else
                echo_error "密码不匹配，请重新输入"
            fi
        done
    fi
    
    # 确认信息
    echo ""
    echo "节点信息:"
    echo "  IP地址: $ip"
    echo "  主机名: $hostname"
    echo "  角色: $role"
    echo "  用户名: $user"
    if [[ "$auth" == /* ]]; then
        echo "  认证方式: SSH密钥 ($auth)"
    else
        echo "  认证方式: 密码"
    fi
    echo ""
    
    read -p "确认添加此节点? [Y/n]: " answer
    if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
        # 如果文件不存在，创建它
        [ ! -f "$NODES_FILE" ] && create_empty_nodes_file
        
        # 添加到文件
        echo "$ip $hostname $role $user $auth" >> "$NODES_FILE"
        echo_info "节点已添加"
    else
        echo_info "已取消添加"
    fi
}

# 批量导入节点
batch_import_nodes() {
    echo ""
    echo_info "批量导入节点"
    echo ""
    
    echo "请选择导入方式:"
    echo "1. 连续IP地址范围"
    echo "2. 手动逐行输入"
    echo "3. 粘贴多行文本"
    echo "0. 返回"
    echo ""
    read -p "请选择 [0-3]: " import_choice
    
    case $import_choice in
        1)
            # 连续IP范围
            echo ""
            echo "配置连续IP地址范围的节点"
            echo ""
            
            # 输入IP范围
            read -p "起始IP (如: 192.168.1.10): " start_ip
            read -p "结束IP最后一位 (如: 20): " end_num
            
            # 提取IP前缀
            ip_prefix=$(echo $start_ip | sed 's/\.[0-9]*$//')
            start_num=$(echo $start_ip | sed 's/.*\.//')
            
            # 输入公共配置
            read -p "主机名前缀 (如: node): " hostname_prefix
            echo "节点角色: 1.master 2.worker"
            read -p "请选择 [1-2]: " role_choice
            [ "$role_choice" = "1" ] && role="master" || role="worker"
            
            read -p "用户名 [root]: " user
            [ -z "$user" ] && user="root"
            
            echo "认证方式: 1.密码 2.密钥"
            read -p "请选择 [1-2]: " auth_choice
            
            if [ "$auth_choice" = "2" ]; then
                read -p "密钥路径: " auth
            else
                read -s -p "密码: " auth
                echo
            fi
            
            # 生成节点列表
            echo ""
            echo "将添加以下节点:"
            for ((i=$start_num; i<=$end_num; i++)); do
                ip="${ip_prefix}.${i}"
                hostname="${hostname_prefix}$(printf "%02d" $i)"
                echo "  $ip $hostname $role"
            done
            
            echo ""
            read -p "确认添加这些节点? [Y/n]: " answer
            if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
                [ ! -f "$NODES_FILE" ] && create_empty_nodes_file
                
                for ((i=$start_num; i<=$end_num; i++)); do
                    ip="${ip_prefix}.${i}"
                    hostname="${hostname_prefix}$(printf "%02d" $i)"
                    echo "$ip $hostname $role $user $auth" >> "$NODES_FILE"
                done
                echo_info "已添加 $((end_num - start_num + 1)) 个节点"
            fi
            ;;
            
        2)
            # 手动逐行输入
            echo ""
            echo "手动输入节点信息（输入空行结束）"
            echo "格式: IP地址 主机名 角色 用户名 密码/密钥路径"
            echo ""
            
            [ ! -f "$NODES_FILE" ] && create_empty_nodes_file
            
            local count=0
            while true; do
                read -p "> " node_line
                if [ -z "$node_line" ]; then
                    break
                fi
                
                # 简单验证格式
                if [[ "$node_line" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}[[:space:]] ]]; then
                    echo "$node_line" >> "$NODES_FILE"
                    ((count++))
                else
                    echo_error "格式错误，请重新输入"
                fi
            done
            
            if [ $count -gt 0 ]; then
                echo_info "已添加 $count 个节点"
            fi
            ;;
            
        3)
            # 粘贴多行文本
            echo ""
            echo "粘贴节点配置（按Ctrl+D结束）:"
            echo "格式: IP地址 主机名 角色 用户名 密码/密钥路径"
            echo ""
            
            [ ! -f "$NODES_FILE" ] && create_empty_nodes_file
            
            # 创建临时文件
            local temp_file="/tmp/nodes_import_$$.txt"
            cat > "$temp_file"
            
            # 处理并验证每行
            local count=0
            while IFS= read -r line; do
                # 跳过空行和注释
                [[ -z "$line" ]] || [[ "$line" =~ ^# ]] && continue
                
                # 简单验证IP格式
                if [[ "$line" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}[[:space:]] ]]; then
                    echo "$line" >> "$NODES_FILE"
                    ((count++))
                fi
            done < "$temp_file"
            
            rm -f "$temp_file"
            
            if [ $count -gt 0 ]; then
                echo_info "已添加 $count 个节点"
            else
                echo_warn "没有有效的节点配置"
            fi
            ;;
            
        0)
            return
            ;;
    esac
}

# 从文件导入
import_from_file() {
    echo ""
    echo_info "从文件导入节点配置"
    echo ""
    
    read -p "请输入文件路径: " import_file
    
    if [ ! -f "$import_file" ]; then
        echo_error "文件不存在: $import_file"
        return
    fi
    
    # 预览文件内容
    echo ""
    echo "文件内容预览:"
    echo "----------------------------------------"
    head -20 "$import_file"
    
    local total_lines=$(wc -l < "$import_file")
    if [ $total_lines -gt 20 ]; then
        echo "... (共 $total_lines 行)"
    fi
    echo "----------------------------------------"
    
    echo ""
    read -p "确认导入此文件? [Y/n]: " answer
    
    if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
        # 备份现有文件
        [ -f "$NODES_FILE" ] && mv "$NODES_FILE" "${NODES_FILE}.bak.$(date +%Y%m%d_%H%M%S)"
        
        # 复制文件
        cp "$import_file" "$NODES_FILE"
        echo_info "节点配置已导入"
        
        # 显示统计
        local node_count=$(grep -v "^#" "$NODES_FILE" | grep -v "^$" | wc -l)
        echo_info "导入了 $node_count 个节点"
    fi
}

# 编辑现有节点
edit_existing_node() {
    echo ""
    echo_info "编辑现有节点"
    
    if [ ! -f "$NODES_FILE" ]; then
        echo_warn "节点清单不存在"
        return
    fi
    
    # 使用默认编辑器
    local editor="${EDITOR:-vi}"
    
    echo ""
    echo "将使用 $editor 编辑器打开节点清单"
    read -p "按回车键继续..."
    
    $editor "$NODES_FILE"
    
    echo_info "编辑完成"
}

# 删除节点
delete_node() {
    echo ""
    echo_info "删除节点"
    
    if [ ! -f "$NODES_FILE" ]; then
        echo_warn "节点清单不存在"
        return
    fi
    
    # 显示节点列表
    echo ""
    echo "当前节点列表:"
    local idx=1
    declare -a node_lines
    
    while IFS= read -r line; do
        [[ "$line" =~ ^# ]] || [[ -z "$line" ]] && continue
        node_lines+=("$line")
        
        ip=$(echo "$line" | awk '{print $1}')
        hostname=$(echo "$line" | awk '{print $2}')
        
        printf "  %2d. %-15s %s\n" $idx "$hostname" "$ip"
        ((idx++))
    done < "$NODES_FILE"
    
    if [ ${#node_lines[@]} -eq 0 ]; then
        echo_warn "没有可删除的节点"
        return
    fi
    
    echo ""
    echo "输入要删除的节点编号（多个用空格分隔，0返回）:"
    read -p "> " delete_nums
    
    if [ "$delete_nums" = "0" ]; then
        return
    fi
    
    # 创建临时文件
    local temp_file="/tmp/nodes_temp_$$.txt"
    
    # 保留注释和空行
    grep "^#\|^$" "$NODES_FILE" > "$temp_file"
    
    # 处理要保留的节点
    for i in "${!node_lines[@]}"; do
        local node_num=$((i + 1))
        local should_delete=0
        
        for num in $delete_nums; do
            if [ "$num" = "$node_num" ]; then
                should_delete=1
                break
            fi
        done
        
        if [ $should_delete -eq 0 ]; then
            echo "${node_lines[$i]}" >> "$temp_file"
        fi
    done
    
    # 替换原文件
    mv "$temp_file" "$NODES_FILE"
    
    echo_info "已删除指定节点"
}

# 配置SSH免密登录
setup_ssh_passwordless() {
    echo ""
    show_separator
    echo "        配置SSH免密登录"
    show_separator
    echo ""
    
    # 检查节点清单
    if [ ! -f "$NODES_FILE" ]; then
        echo_error "节点清单文件不存在"
        return 1
    fi
    
    # 读取节点信息
    local nodes_array=()
    while IFS= read -r line; do
        [[ "$line" =~ ^# ]] || [[ -z "$line" ]] && continue
        nodes_array+=("$line")
    done < "$NODES_FILE"
    
    if [ ${#nodes_array[@]} -eq 0 ]; then
        echo_error "节点清单为空"
        return 1
    fi
    
    echo_info "发现 ${#nodes_array[@]} 个节点"
    echo ""
    
    # 显示节点列表
    echo "将为以下节点配置免密登录:"
    echo "----------------------------------------"
    for node_line in "${nodes_array[@]}"; do
        ip=$(echo "$node_line" | awk '{print $1}')
        hostname=$(echo "$node_line" | awk '{print $2}')
        user=$(echo "$node_line" | awk '{print $4}')
        auth=$(echo "$node_line" | awk '{print $5}')
        
        # 判断当前认证方式
        if [[ "$auth" == /* ]]; then
            auth_type="已配置密钥"
        else
            auth_type="密码认证"
        fi
        
        printf "  %-15s %-15s %-8s %s\n" "$hostname" "$ip" "$user" "$auth_type"
    done
    echo "----------------------------------------"
    echo ""
    
    # 选择操作模式
    echo "请选择操作模式:"
    echo "1. 自动配置所有节点（推荐）"
    echo "2. 选择特定节点配置"
    echo "3. 测试现有免密配置"
    echo "0. 返回"
    echo ""
    read -p "请选择 [0-3]: " mode
    
    case $mode in
        1)
            auto_setup_passwordless "${nodes_array[@]}"
            ;;
        2)
            selective_setup_passwordless "${nodes_array[@]}"
            ;;
        3)
            test_passwordless_access "${nodes_array[@]}"
            ;;
        0)
            return
            ;;
        *)
            echo_error "无效选择"
            ;;
    esac
}

# 自动配置所有节点的免密登录
auto_setup_passwordless() {
    local nodes_array=("$@")
    
    echo ""
    echo_info "开始自动配置SSH免密登录..."
    echo ""
    
    # 检查本地密钥
    local key_file="/root/.ssh/id_rsa"
    local pub_key_file="/root/.ssh/id_rsa.pub"
    
    if [ ! -f "$key_file" ] || [ ! -f "$pub_key_file" ]; then
        echo_info "本地SSH密钥不存在，正在生成..."
        ssh-keygen -t rsa -b 2048 -N "" -f "$key_file" -q
        
        if [ $? -eq 0 ]; then
            echo_info "SSH密钥生成成功"
        else
            echo_error "SSH密钥生成失败"
            return 1
        fi
    else
        echo_info "使用现有SSH密钥: $key_file"
    fi
    
    # 读取公钥内容
    local pub_key=$(cat "$pub_key_file")
    
    # 检查sshpass
    if ! command -v sshpass &>/dev/null; then
        echo_warn "未安装sshpass，尝试安装..."
        if ! yum install -y sshpass &>/dev/null 2>&1; then
            echo_error "sshpass安装失败，无法继续自动配置"
            echo_info "请手动安装sshpass或使用手动方式配置"
            return 1
        fi
    fi
    
    local success_count=0
    local fail_count=0
    local skip_count=0
    
    echo ""
    echo "开始配置各节点..."
    echo ""
    
    for node_line in "${nodes_array[@]}"; do
        ip=$(echo "$node_line" | awk '{print $1}')
        hostname=$(echo "$node_line" | awk '{print $2}')
        user=$(echo "$node_line" | awk '{print $4}')
        auth=$(echo "$node_line" | awk '{print $5}')
        
        echo -n "[$hostname] "
        
        # 如果已经是密钥认证，跳过
        if [[ "$auth" == /* ]]; then
            # 测试密钥是否有效
            if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no \
               -i "$auth" "$user@$ip" "echo ok" &>/dev/null 2>&1; then
                echo -e "${GREEN}✓${NC} 已配置免密（使用现有密钥）"
                ((skip_count++))
                continue
            fi
        fi
        
        # 如果可以免密连接，跳过
        if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no \
           "$user@$ip" "echo ok" &>/dev/null 2>&1; then
            echo -e "${GREEN}✓${NC} 已配置免密"
            ((skip_count++))
            continue
        fi
        
        # 使用密码配置免密
        if [[ "$auth" != /* ]]; then
            # 创建.ssh目录并设置权限
            sshpass -p "$auth" ssh -o StrictHostKeyChecking=no "$user@$ip" \
                "mkdir -p ~/.ssh && chmod 700 ~/.ssh" &>/dev/null 2>&1
            
            # 添加公钥到authorized_keys
            if sshpass -p "$auth" ssh -o StrictHostKeyChecking=no "$user@$ip" \
               "echo '$pub_key' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys" &>/dev/null 2>&1; then
                
                # 验证免密是否成功
                if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no \
                   "$user@$ip" "echo ok" &>/dev/null 2>&1; then
                    echo -e "${GREEN}✓${NC} 配置成功"
                    ((success_count++))
                else
                    echo -e "${RED}✗${NC} 配置失败（验证失败）"
                    ((fail_count++))
                fi
            else
                echo -e "${RED}✗${NC} 配置失败（无法添加公钥）"
                ((fail_count++))
            fi
        else
            echo -e "${RED}✗${NC} 配置失败（密钥文件无效）"
            ((fail_count++))
        fi
    done
    
    # 显示汇总
    echo ""
    show_separator
    echo "        配置结果汇总"
    show_separator
    echo -e "${GREEN}成功配置:${NC} $success_count 个节点"
    echo -e "${BLUE}已存在免密:${NC} $skip_count 个节点"
    echo -e "${RED}配置失败:${NC} $fail_count 个节点"
    
    if [ $fail_count -eq 0 ]; then
        echo ""
        echo_info "所有节点免密配置完成！"

        # 询问是否更新节点清单
        echo ""
        read -p "是否更新节点清单，将密码改为密钥路径? [Y/n]: " answer
        if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
            update_nodes_file_with_keys
        fi
    else
        echo ""
        echo_warn "部分节点配置失败，请检查："
        echo "  1. 节点是否可达"
        echo "  2. 用户名密码是否正确"
        echo "  3. SSH服务是否正常"
    fi

    # 等待用户确认
    echo ""
    read -p "按回车键返回菜单..."
}

# 选择特定节点配置
selective_setup_passwordless() {
    local nodes_array=("$@")
    
    echo ""
    echo "选择要配置免密的节点:"
    echo ""
    
    # 显示节点列表供选择
    local idx=1
    for node_line in "${nodes_array[@]}"; do
        ip=$(echo "$node_line" | awk '{print $1}')
        hostname=$(echo "$node_line" | awk '{print $2}')
        user=$(echo "$node_line" | awk '{print $4}')
        
        printf "  %2d. %-15s %-15s %s\n" $idx "$hostname" "$ip" "$user"
        ((idx++))
    done
    
    echo ""
    echo "输入要配置的节点编号（多个用空格分隔，all表示所有）:"
    read -p "> " selected
    
    if [ "$selected" = "all" ]; then
        auto_setup_passwordless "${nodes_array[@]}"
    else
        # 构建选中的节点数组
        local selected_nodes=()
        for num in $selected; do
            if [ $num -ge 1 ] && [ $num -le ${#nodes_array[@]} ]; then
                selected_nodes+=("${nodes_array[$((num-1))]}")
            fi
        done
        
        if [ ${#selected_nodes[@]} -gt 0 ]; then
            auto_setup_passwordless "${selected_nodes[@]}"
        else
            echo_error "没有选择有效的节点"
        fi
    fi
}

# 测试免密访问
test_passwordless_access() {
    local nodes_array=("$@")
    
    echo ""
    echo_info "测试SSH免密访问..."
    echo ""
    
    local success_count=0
    local fail_count=0
    
    for node_line in "${nodes_array[@]}"; do
        ip=$(echo "$node_line" | awk '{print $1}')
        hostname=$(echo "$node_line" | awk '{print $2}')
        user=$(echo "$node_line" | awk '{print $4}')
        
        echo -n "[$hostname] "
        
        # 测试免密连接
        if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no \
           "$user@$ip" "hostname" &>/dev/null 2>&1; then
            echo -e "${GREEN}✓${NC} 免密访问正常"
            ((success_count++))
        else
            echo -e "${RED}✗${NC} 免密访问失败"
            ((fail_count++))
        fi
    done
    
    echo ""
    echo "----------------------------------------"
    echo -e "${GREEN}成功:${NC} $success_count 个节点"
    echo -e "${RED}失败:${NC} $fail_count 个节点"
    
    if [ $fail_count -gt 0 ]; then
        echo ""
        echo_warn "部分节点免密访问失败"
        read -p "是否为失败的节点配置免密? [Y/n]: " answer
        if [[ "$answer" != "n" ]] && [[ "$answer" != "N" ]]; then
            # 筛选出失败的节点重新配置
            local failed_nodes=()
            for node_line in "${nodes_array[@]}"; do
                ip=$(echo "$node_line" | awk '{print $1}')
                user=$(echo "$node_line" | awk '{print $4}')
                
                if ! ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no \
                   "$user@$ip" "hostname" &>/dev/null 2>&1; then
                    failed_nodes+=("$node_line")
                fi
            done
            
            if [ ${#failed_nodes[@]} -gt 0 ]; then
                auto_setup_passwordless "${failed_nodes[@]}"
            fi
        fi
    else
        echo ""
        echo_info "所有节点免密访问正常！"
    fi
}

# 更新节点清单文件，将密码改为密钥路径
update_nodes_file_with_keys() {
    echo ""
    echo_info "更新节点清单文件..."
    
    # 备份原文件
    cp "$NODES_FILE" "${NODES_FILE}.bak.$(date +%Y%m%d_%H%M%S)"
    
    # 创建临时文件
    local temp_file="/tmp/nodes_temp_$$.txt"
    
    # 处理每一行
    while IFS= read -r line; do
        # 保留注释和空行
        if [[ "$line" =~ ^# ]] || [[ -z "$line" ]]; then
            echo "$line" >> "$temp_file"
            continue
        fi
        
        # 解析节点信息
        ip=$(echo "$line" | awk '{print $1}')
        hostname=$(echo "$line" | awk '{print $2}')
        role=$(echo "$line" | awk '{print $3}')
        user=$(echo "$line" | awk '{print $4}')
        auth=$(echo "$line" | awk '{print $5}')
        
        # 如果已经是密钥路径，保持不变
        if [[ "$auth" == /* ]]; then
            echo "$line" >> "$temp_file"
        else
            # 测试是否可以免密访问
            if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no -o PasswordAuthentication=no \
               "$user@$ip" "echo ok" &>/dev/null 2>&1; then
                # 更新为密钥路径
                echo "$ip $hostname $role $user /root/.ssh/id_rsa" >> "$temp_file"
            else
                # 保持原样
                echo "$line" >> "$temp_file"
            fi
        fi
    done < "$NODES_FILE"
    
    # 替换原文件
    mv "$temp_file" "$NODES_FILE"
    
    echo_info "节点清单已更新"
    echo_info "原文件备份为: ${NODES_FILE}.bak.$(date +%Y%m%d_%H%M%S)"
}

# 检查sshpass
check_sshpass_requirement() {
    if command -v sshpass &>/dev/null; then
        return 0
    fi
    
    echo_warn "批量管理需要sshpass（密码认证）或SSH密钥"
    echo ""
    echo "您可以："
    echo "1. 安装sshpass（需要先配置YUM源）"
    echo "2. 使用SSH密钥认证"
    echo "3. 返回主菜单"
    echo ""
    read -p "请选择 [1-3]: " choice
    
    case $choice in
        1)
            if yum install -y sshpass 2>/dev/null; then
                echo_info "sshpass安装成功"
                return 0
            else
                echo_error "sshpass安装失败，请先配置YUM源"
                return 1
            fi
            ;;
        2)
            echo_info "请确保nodes.conf中使用密钥路径而非密码"
            echo "示例: 192.168.1.10 master01 master root /root/.ssh/id_rsa"
            return 0
            ;;
        3)
            return 1
            ;;
    esac
}

# ================== 主菜单函数 ==================

# 单节点操作菜单
single_node_menu() {
    while true; do
        clear
        echo "=========================================="
        echo "        单节点检查和初始化"
        echo "=========================================="
        echo ""
        
        # 显示系统信息
        if [ -f /etc/os-release ]; then
            . /etc/os-release
            echo "系统: $NAME $VERSION_ID"
        fi
        echo "主机名: $(hostname)"
        echo ""
        
        # 检查YUM源状态
        if mount | grep -q "/mnt/cdrom"; then
            echo -e "YUM源: ${GREEN}本地ISO已挂载${NC}"
        elif yum makecache &>/dev/null 2>&1; then
            echo -e "YUM源: ${GREEN}正常${NC}"
        else
            echo -e "YUM源: ${YELLOW}未配置或异常${NC}"
        fi
        
        echo ""
        echo "请选择操作:"
        echo "1. 执行完整检查和修复"
        echo "2. 配置本地YUM源"
        echo "3. 只检查不修复"
        echo "4. 安装sshpass（批量管理需要）"
        echo "5. 显示上次检查结果"
        echo "0. 返回主菜单"
      echo ""
        read -p "请选择 [0-5]: " choice
        
        case $choice in
            1)
                run_all_checks
                echo ""
                read -p "按回车键继续..."
                ;;
            2)
                setup_local_yum_source
                echo ""
                read -p "按回车键继续..."
                ;;
            3)
                echo ""
                echo_info "只检查模式（不会修改任何配置）"
                export CHECK_ONLY=1
                run_all_checks
                unset CHECK_ONLY
                echo ""
                read -p "按回车键继续..."
                ;;
            4)
                echo ""
                if command -v sshpass &>/dev/null; then
                    echo_info "sshpass已安装"
                    sshpass -V
                else
                    echo_info "安装sshpass..."
                    if yum install -y sshpass 2>/dev/null; then
                        echo_info "sshpass安装成功"
                    else
                        echo_error "sshpass安装失败"
                        echo_info "请先配置YUM源（选择2）"
                    fi
                fi
                echo ""
                read -p "按回车键继续..."
                ;;
            5)
                if [ ${#CHECK_STATUS[@]} -gt 0 ]; then
                    show_summary
                else
                    echo_warn "还没有执行过检查"
                fi
                echo ""
                read -p "按回车键继续..."
                ;;
            0)
                return
                ;;
            *)
                echo_error "无效选择"
                sleep 1
                ;;
        esac
    done
}

# 批量管理菜单
batch_management_menu() {
    while true; do
        clear
        echo "=========================================="
        echo "        批量节点管理"
        echo "=========================================="
        echo ""
        
        if [ -f "$NODES_FILE" ]; then
            local node_count=$(grep -v "^#" "$NODES_FILE" | grep -v "^$" | wc -l)
            echo -e "节点清单: ${GREEN}$NODES_FILE${NC} (${node_count}个节点)"
        else
            echo -e "节点清单: ${YELLOW}未配置${NC}"
        fi
        
        if command -v sshpass &>/dev/null; then
            echo -e "sshpass: ${GREEN}已安装${NC}"
        else
            echo -e "sshpass: ${YELLOW}未安装${NC} (密码认证需要)"
        fi
        
        echo ""
        echo "请选择操作:"
        echo "1. 配置节点清单"
        echo "2. 批量检查和初始化"
        echo "3. 安装sshpass"
        echo "4. 配置SSH免密登录"
        echo "0. 返回主菜单"
        echo ""
        read -p "请选择 [0-4]: " choice
        
        case $choice in
            1)
                configure_nodes
                read -p "按回车键继续..."
                ;;
            2)
                if [ ! -f "$NODES_FILE" ]; then
                    echo_error "请先配置节点清单"
                else
                    if check_sshpass_requirement; then
                        batch_check_and_init
                    fi
                fi
                read -p "按回车键继续..."
                ;;
            3)
                if command -v sshpass &>/dev/null; then
                    echo_info "sshpass已安装"
                else
                    if yum install -y sshpass 2>/dev/null; then
                        echo_info "sshpass安装成功"
                    else
                        echo_error "安装失败，请先配置YUM源"
                    fi
                fi
                read -p "按回车键继续..."
                ;;
            4)
                if [ ! -f "$NODES_FILE" ]; then
                    echo_error "请先配置节点清单"
                else
                    setup_ssh_passwordless
                fi
                read -p "按回车键继续..."
                ;;
            0)
                return
                ;;
            *)
                echo_error "无效选择"
                sleep 1
                ;;
        esac
    done
}

# 主菜单
main_menu() {
    while true; do
        clear
        show_separator
        echo "        QFusion统一管理工具"
        show_separator
        echo ""
        echo "请选择操作模式:"
        echo ""
        echo "1. 单节点操作（本机）"
        echo "2. 批量节点管理"
        echo "3. 配置本地YUM源"
        echo "4. 快速检查（只检查本机）"
        echo "0. 退出"
        echo ""
        read -p "请选择 [0-4]: " choice
        
        case $choice in
            1)
                single_node_menu
                ;;
            2)
                batch_management_menu
                ;;
            3)
                setup_local_yum_source
                read -p "按回车键继续..."
                ;;
            4)
                echo ""
                echo_info "快速检查模式"
                export CHECK_ONLY=1
                run_all_checks
                unset CHECK_ONLY
                echo ""
                read -p "按回车键继续..."
                ;;
            0)
                echo_info "退出程序"
                exit 0
                ;;
            *)
                echo_error "无效选择"
                sleep 1
                ;;
        esac
    done
}

# ================== 主函数 ==================

main() {
    # 检查是否为root用户
    if [ "$EUID" -ne 0 ]; then
        echo_error "请使用root用户运行此脚本"
        exit 1
    fi
    
    # 处理命令行参数
    if [ $# -gt 0 ]; then
        case "$1" in
            --remote-init)
                # 远程初始化模式，直接执行检查和修复
                echo ""
                echo "=========================================="
                echo "     QFusion远程节点初始化"
                echo "=========================================="
                echo ""
                # 设置自动确认模式
                export AUTO_CONFIRM=1
                run_all_checks
                # 保存返回值
                result=$?
                echo ""
                echo "=========================================="
                echo "     远程节点初始化完成"
                echo "=========================================="
                # 始终返回0，表示成功完成（即使有警告）
                exit 0
                ;;
            --check)
                # 只检查模式
                export CHECK_ONLY=1
                run_all_checks
                exit $?
                ;;
            --help)
                echo "用法: $0 [选项]"
                echo ""
                echo "选项:"
                echo "  --remote-init  远程初始化模式"
                echo "  --check        只检查不修复"
                echo "  --help         显示帮助"
                echo ""
                echo "无参数运行将显示交互式菜单"
                exit 0
                ;;
            *)
                echo_error "未知参数: $1"
                echo "使用 --help 查看帮助"
                exit 1
                ;;
        esac
    fi
    
    # 显示主菜单
    main_menu
}

# 运行主函数
main "$@"
